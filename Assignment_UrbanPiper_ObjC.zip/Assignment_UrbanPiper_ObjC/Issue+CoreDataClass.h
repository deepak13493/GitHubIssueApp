//
//  Issue+CoreDataClass.h
//  Assignment_UrbanPiper_ObjC
//
//  Created by Bhagyashree on 22/11/16.
//  Copyright © 2016 Bhagyashree. All rights reserved.
//  This file was automatically generated and should not be edited.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class Comment;

NS_ASSUME_NONNULL_BEGIN

@interface Issue : NSManagedObject

@end

NS_ASSUME_NONNULL_END

#import "Issue+CoreDataProperties.h"
