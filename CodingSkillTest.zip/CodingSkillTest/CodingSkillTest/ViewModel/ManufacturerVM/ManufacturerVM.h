//
//  ManufacturerVM.h
//  CodingSkillTest
//
//  Created by Ajay Kumar Singh on 11/30/16.
//
//

#import <Foundation/Foundation.h>
#import "ErrorResponse.h"

@interface ManufacturerVM : NSObject

@property (nonatomic, strong) NSString *selectedManufacturerName;
@property (nonatomic, strong) NSString *selectedManufacturerUniqueID;


- (NSInteger)getAllManufacturersCount;
- (NSString*)getManufacturerNameForRow:(NSInteger)row;
- (NSString *)getManufacturerUniqueIDForRow:(NSInteger)row;
- (NSInteger)getTotalPageCount;

- (void)getManufacturerDataForPage:(NSInteger)page pageSize:(NSInteger)pageSize onCompletion:(void (^)())onCompletion didFailWithError:(void (^)(ErrorResponse *error))failedWithError;

@end
