//
//  ModelViewController.m
//  CodingSkillTest

#import "ModelViewController.h"
 #import "ModelVM.h"
#import "MBProgressHUD.h"
#import "CustomTableViewCell.h"
#import "YearViewController.h"
#import "AppDelegate.h"
#import "Constant.h"

@interface ModelViewController () <UITableViewDelegate, UITableViewDataSource, UISearchBarDelegate>

@property (nonatomic, weak) IBOutlet UITableView *modelTableView;
@property (nonatomic, weak) IBOutlet UISearchBar *searchBarView;
@property (nonatomic, weak) IBOutlet UIView *errorView;
@property (nonatomic, weak) IBOutlet UILabel *errorLabelMessage;
@property (nonatomic, strong) ModelVM *vmDataSet;

@end

@implementation ModelViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"Model";
    
    // Do any additional setup after loading the view.
    self.vmDataSet = [[ModelVM alloc]init];
    [self fetchModelData];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    if ([segue.identifier isEqualToString:@"YearViewControllerSegue"]) {
        YearViewController *vc = [segue destinationViewController];
        vc.modelReferenceVM = self.vmDataSet;
        vc.manufaturerReferenceVM = self.manufaturerReferenceVM;
    }
}

#pragma mark - Fetch request helper

- (void)fetchModelData {
    if (![self isNetworkAvailable]) {
        return;
    }

    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    __weak ModelViewController *weakSelf = self;
    [self.vmDataSet getModelDataForManufacturer:self.manufaturerReferenceVM.selectedManufacturerUniqueID page:0 pageSize:0 onCompletion:^{
        [weakSelf.modelTableView reloadData];
        [MBProgressHUD hideHUDForView:weakSelf.view animated:YES];
    } didFailWithError:^(ErrorResponse *error) {
        [weakSelf showErrorMessage:error.errorMessage];
        [MBProgressHUD hideHUDForView:weakSelf.view animated:YES];
    }];
}

#pragma mark - TableView Delegate

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self.vmDataSet getAllCountOfModelData];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *MyIdentifier = @"CustomTableViewCell";
    CustomTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:MyIdentifier];
    NSString *cellName = [self.vmDataSet getModelNameForRow:indexPath.row];
    NSString * cellUniqueId = [self.vmDataSet getModelUniqueIdForRow:indexPath.row];
    [cell updateCellInformationByCellName:cellName andCellUniqueId:cellUniqueId];
    if (indexPath.row %2 == 0) {
        [cell setBackgroundColor:[UIColor colorWithRed:218/255.0 green:229/255.0 blue:228/255.0 alpha:1]];
    } else {
        [cell setBackgroundColor:[UIColor colorWithRed:220/255.0 green:232/255.0 blue:194/255.0 alpha:1]];
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (![self isNetworkAvailable]) {
        return;
    }

    CustomTableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    self.vmDataSet.selectedModelName = cell.cellName.text;
    self.vmDataSet.selectedModelUniqueID = cell.cellUniqueID;

    [self performSegueWithIdentifier:@"YearViewControllerSegue" sender:nil];
}

#pragma mark - Searchbar helper

- (BOOL)searchBarShouldBeginEditing:(UISearchBar *)searchBar {
    self.vmDataSet.isSearchingEnabled = YES;
    return YES;
}

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText {
    if (![self isNetworkAvailable]) {
        return;
    }else if (searchText.length <= 0) {
        self.vmDataSet.isSearchingEnabled = NO;
    } else {
            self.vmDataSet.isSearchingEnabled = YES;
            [self.vmDataSet filterModelNameForSearchString:searchText];
    }
    [self.modelTableView reloadData];
}
- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar {
    if ([self.searchBarView canResignFirstResponder]) {
        [self.searchBarView resignFirstResponder];
    }
}

#pragma mark - Error Handler Helper

- (void)showErrorMessage:(NSString*)errorMsg {
    self.errorView.hidden = NO;
    self.errorLabelMessage.text = errorMsg;
}

#pragma mark - IBActrion

- (IBAction)didRetryButtonClicked:(id)sender {
    self.errorView.hidden = YES;
    [self fetchModelData];
}

#pragma mark - Check network availability 
- (BOOL)isNetworkAvailable {
    AppDelegate *appDelegate = (AppDelegate*)[UIApplication sharedApplication].delegate;
    
    if(!appDelegate.isNetworkAvailable) {
        [self showErrorMessage:kNetworkErrorMessage];
        return NO;
     }
    return YES;
}
@end
