//
//  APIManager.m
//  Assignment_UrbanPiper_ObjC
//
//  Created by Bhagyashree on 22/11/16.
//  Copyright © 2016 Bhagyashree. All rights reserved.
//

#import "APIManager.h"

@implementation APIManager

-(void)request :(NSString*)urlString{
    NSURLSessionConfiguration *defaultConfiguration = [NSURLSessionConfiguration defaultSessionConfiguration];
    
    NSURLSession *sessionWithoutADelegate = [NSURLSession sessionWithConfiguration:defaultConfiguration];
    NSURL *url = [NSURL URLWithString:urlString];
    
    [[sessionWithoutADelegate dataTaskWithURL:url completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        if (data) {
            [self.apiManagerDelegate response:data WithError:error];
        }
        else{
            [self.apiManagerDelegate response:nil WithError:error];
        }
    }] resume];
              
}


@end
