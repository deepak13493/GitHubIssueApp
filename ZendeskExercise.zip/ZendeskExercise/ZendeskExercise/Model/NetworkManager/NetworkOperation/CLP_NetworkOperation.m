//
//  CLPNetworkOperation.m
//  ZendeskExercise
//
//  Created by Ajay Kumar Singh on 11/24/16.
//  Copyright © 2016 Zendesk. All rights reserved.
//

#import "CLP_NetworkOperation.h"

#define AUTH_CREDENTIAL @"acooke+techtest@zendesk.com:mobile"

@interface CLP_NetworkOperation () <NSURLSessionDataDelegate>

@property (nonatomic, strong) NSURL *url;
@property (nonatomic, strong) NSURLSessionDataTask *dataTask;

@end

@implementation CLP_NetworkOperation

-(instancetype)initWithURL:(NSURL *)url {
    
    if (self = [super init]) {
        self.url = url;
    }
    return self;
}

 
- (void)startSessionDataTask {
    if (self.url) {        
        NSURLSessionConfiguration *defaultConfigObject = [NSURLSessionConfiguration defaultSessionConfiguration];
        NSURLSession *defaultSession = [NSURLSession sessionWithConfiguration: defaultConfigObject delegate: self delegateQueue: [NSOperationQueue mainQueue]];
        
        NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:self.url
                                                               cachePolicy:NSURLRequestUseProtocolCachePolicy
                                                           timeoutInterval:60.0];
        NSString *authStr = AUTH_CREDENTIAL;
        NSData *authData = [authStr dataUsingEncoding:NSUTF8StringEncoding];
        NSString *authValue = [NSString stringWithFormat: @"Basic %@",[authData base64EncodedStringWithOptions:0]];
        [request setValue:authValue forHTTPHeaderField:@"Authorization"];
        
        NSURLSessionDataTask *postDataTask = [defaultSession dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
            if(error == nil)
            {
                self.completionBlock(data);
            } else {
                CLP_ErrorResponse *errorResponse = [[CLP_ErrorResponse alloc]init];
                errorResponse.errorCode = [NSString stringWithFormat:@"%ld",(long)error.code];
                errorResponse.errorMessage = [error localizedDescription];
                self.errorBlock(errorResponse);
            }
        }];
        
        [postDataTask resume];
        
    }
}


- (void)URLSession:(NSURLSession *)session didReceiveChallenge:(NSURLAuthenticationChallenge *)challenge completionHandler:(void (^)(NSURLSessionAuthChallengeDisposition, NSURLCredential *))completionHandler{
    
    NSURLCredential *newCredential = [NSURLCredential credentialWithUser:@"acooke+techtest@zendesk.com"
                                                                password:@"mobile"
                                                             persistence:NSURLCredentialPersistenceForSession];
    //    [[challenge sender] useCredential:newCredential forAuthenticationChallenge:challenge];
    completionHandler(NSURLSessionAuthChallengeUseCredential, newCredential);
}

- (BOOL)connection:(NSURLSession *)connection canAuthenticateAgainstProtectionSpace:(NSURLProtectionSpace *)protectionSpace {
    return [protectionSpace.authenticationMethod isEqualToString:NSURLAuthenticationMethodServerTrust];
}

-(void)dealloc {
    NSLog(@"Network Operation object deallocated");
}
@end
