//
//  IssueViewController.m
//  Assignment_UrbanPiper_ObjC
//
//  Created by Bhagyashree on 22/11/16.
//  Copyright © 2016 Bhagyashree. All rights reserved.
//

#import "IssueViewController.h"
#import "BaseViewController.h"
#import "IssueDataManager.h"
#import "IssueTableViewCell.h"
#import "CommentViewController.h"

@interface IssueViewController ()
@property (weak, nonatomic) IBOutlet UITableView *issueTableView;
@property (nonatomic, strong) BaseViewController *baseView;
@property (nonatomic, strong) IssueDataManager *issueDataManager;
@property (nonatomic, strong) Issue   *issues;

@end

@implementation IssueViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _baseView  = [[BaseViewController alloc]init];
    
    
}

-(void) loadData{
    [_baseView showActivityView];
    // Check the code
    //TO DO
    Issue *issues = [_issueDataManager fetch:];
    
    if (issues) {
        _issues = issues;
        [_issueTableView reloadData];
    }
    else{
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Please check your Network, If it is ok" preferredStyle:UIAlertControllerStyleAlert];
        [alert addAction:[UIAlertAction actionWithTitle:@"Retry" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
            [self loadData];
        }]];
        [self presentViewController:alert animated:YES completion:nil];
    }
    [_baseView hideActivityView];
    
    
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    // To Do
    return [_issues count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    IssueTableViewCell *issueCell = (IssueTableViewCell *) [tableView dequeueReusableCellWithIdentifier:@"IssueTableViewCell"];
    
    //TO DO
    [issueCell configureCell:[[_issues objectAtIndex: indexPath.row] title] andDeatils:[[_issues objectAtIndex: indexPath.row] details]];
    
    return issueCell;
    
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    
    CommentViewController *commentViewController = [storyBoard instantiateViewControllerWithIdentifier:@"CommentViewController"];
    [self.navigationController pushViewController:commentViewController animated:YES];
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
