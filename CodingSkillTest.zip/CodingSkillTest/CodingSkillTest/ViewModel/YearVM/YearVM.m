//
//  YearVM.m
//  CodingSkillTest
//
//  Created by Ajay Kumar Singh on 11/30/16.
//
//

#import "YearVM.h"
#import "DataManager.h"
#import "CommonModelClass.h"

@interface YearVM ()

@property (nonatomic, strong) NSMutableArray *yearStoredData;

@end

@implementation YearVM

- (instancetype)init {
    if (self = [super init]) {
        self.yearStoredData = [[NSMutableArray alloc]init];
    }
    return self;
}

#pragma mark - Web service call to fetch built date 

- (void)getYearlDataForManufacturer:(NSString *)manufacturerID andMainTYpe:(NSString*)maintype onCompletion:(void (^)())onCompletion didFailWithError:(void (^)(ErrorResponse *error))failedWithError{
    
    if ([self.yearStoredData count] > 0) {
        [self.yearStoredData removeAllObjects];
    }
    

    DataManager *dataManager = [DataManager sharedManager];
    __weak YearVM *weakSelf = self;
    
    [dataManager getYearlDataForManufacturer:manufacturerID andMainTYpe:maintype onCompletion:^(Year *yearData) {
        for (NSDictionary *eachData in yearData.yearDetails) {
            NSString *keyName = [[eachData allKeys]objectAtIndex:0];
            NSString *value = [eachData objectForKey:keyName];
            CommonModelClass *eachModelData = [[CommonModelClass alloc]init];
            eachModelData.name = keyName;
            eachModelData.uniqueID = value;
            [weakSelf.yearStoredData addObject:eachModelData];
        }
        onCompletion();
    } didFailWithError:^(ErrorResponse *error) {
        failedWithError(error);
    }];
}

#pragma mark - Public helper function

- (NSInteger)getAllYearDataCount {
    return [self.yearStoredData count];
}

/*
    Function to get year name
 */
- (NSString*)getYearNameForRow:(NSInteger)row {
    if ([self.yearStoredData count] > 0) {
        CommonModelClass *manufacturerData  =  (CommonModelClass*)[self.yearStoredData objectAtIndex:row];
        return manufacturerData.name;
    }
    return nil;
}

/*
    Function to get year Unique ID
 */
- (NSString *)getYearUniqueIDForRow:(NSInteger)row {
    if ([self.yearStoredData count] > 0) {
        CommonModelClass *manufacturerData  =  (CommonModelClass*)[self.yearStoredData objectAtIndex:row];
        return manufacturerData.uniqueID;
    }
    return nil;
}

@end
