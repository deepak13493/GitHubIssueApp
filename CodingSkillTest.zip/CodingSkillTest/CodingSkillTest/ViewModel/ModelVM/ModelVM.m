//
//  ModelVM.m
//  CodingSkillTest
//


#import "ModelVM.h"
#import "DataManager.h"
#import "CommonModelClass.h"

@interface ModelVM ()

@property (nonatomic, strong) NSMutableArray *modelStoredData;
@property (nonatomic, strong) NSArray *searchingDataArray;

@end

@implementation ModelVM

- (instancetype)init {
    if (self = [super init]) {
        self.modelStoredData = [[NSMutableArray alloc]init];
     }
    return self;
}

#pragma mark - Web service call to fetch All Model details

- (void)getModelDataForManufacturer:(NSString *)manufacturerID page:(NSInteger)page pageSize:(NSInteger)pageSize onCompletion:(void (^)())onCompletion didFailWithError:(void (^)(ErrorResponse *error))failedWithError {
    
    if ([self.modelStoredData count] > 0) {
        [self.modelStoredData removeAllObjects];
    }
    if (self.searchingDataArray) {
        self.searchingDataArray = nil;
    }

    DataManager *dataManager = [DataManager sharedManager];
    __weak ModelVM *weakSelf = self;
    
    [dataManager getModelDataForManufacturer:manufacturerID page:page pageSize:pageSize onCompletion:^(Model *modelData) {
         for (NSDictionary *eachData in modelData.modelDetails) {
            NSString *keyName = [[eachData allKeys]objectAtIndex:0];
            NSString *value = [eachData objectForKey:keyName];
            CommonModelClass *eachModelData = [[CommonModelClass alloc]init];
            eachModelData.name = value;
            eachModelData.uniqueID = keyName;
            [weakSelf.modelStoredData addObject:eachModelData];
        }
        onCompletion();
    } didFailWithError:^(ErrorResponse *error) {
        failedWithError(error);
    }];
}

#pragma mark - Public helper function

/*
    Function to get total model count
 */

- (NSInteger)getAllCountOfModelData {
    if (self.isSearchingEnabled) {
        return [self.searchingDataArray count];
    }
    return [self.modelStoredData count];
}

/*
    Function to get model name
 */
- (NSString*)getModelNameForRow:(NSInteger)row {
    if (self.isSearchingEnabled && [self.modelStoredData count] > 0) {
        CommonModelClass *modelData = (CommonModelClass*) [self.searchingDataArray objectAtIndex:row];
        return modelData.name;
    } else if ([self.modelStoredData count] > 0){
         CommonModelClass *modelData =  (CommonModelClass*) [self.modelStoredData objectAtIndex:row];
        return modelData.name;
    }
    return nil;
}

/*
    Function to get model Unique ID
 */
- (NSString *)getModelUniqueIdForRow:(NSInteger)row {
    if (self.isSearchingEnabled && [self.modelStoredData count] > 0) {
        CommonModelClass *modelData = (CommonModelClass*)[self.searchingDataArray objectAtIndex:row];
        return modelData.uniqueID;
    }
    else if ([self.modelStoredData count] > 0) {
        CommonModelClass *modelData = (CommonModelClass*)[self.modelStoredData objectAtIndex:row];
        return modelData.uniqueID;
    }
    return nil;
}

#pragma mark - Search helper - Filter data from datasource

- (NSArray*)filterModelNameForSearchString:(NSString*)searchString {
    if (self.searchingDataArray != nil) {
        self.searchingDataArray  = nil;
    }
    NSPredicate *filterPredicate = [NSPredicate predicateWithFormat:@"name contains[cd] %@", searchString];
    self.searchingDataArray = [self.modelStoredData filteredArrayUsingPredicate:filterPredicate];
    return self.searchingDataArray;
}
@end
