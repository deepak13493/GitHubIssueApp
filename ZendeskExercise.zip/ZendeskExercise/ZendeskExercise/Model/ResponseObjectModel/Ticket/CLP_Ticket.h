//
//  CLPTicket.h
//  ZendeskExercise
//
//  Created by Ajay Kumar Singh on 11/24/16.
//  Copyright © 2016 Zendesk. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CLP_Constant.h"

@interface CLP_Ticket : NSObject

@property(nonatomic, strong) NSString *subject;
@property(nonatomic, strong) NSString *ticketDescription;
@property(nonatomic, strong) NSNumber *ticketNumber;
@property(nonatomic, assign) TicketStatus ticketStatus;

@end
