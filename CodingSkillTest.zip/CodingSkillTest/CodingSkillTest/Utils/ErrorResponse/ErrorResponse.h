//
//  ErrorResponse.h
//  CodingSkillTest
 

#import <Foundation/Foundation.h>

@interface ErrorResponse : NSObject

@property(nonatomic,retain)NSString *errorCode;
@property (nonatomic,retain) NSString *errorMessage;

@end
