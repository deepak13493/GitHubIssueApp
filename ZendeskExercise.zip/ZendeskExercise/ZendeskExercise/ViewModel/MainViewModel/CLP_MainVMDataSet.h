//
//  CLPMainVMDataSet.h
//  ZendeskExercise
//
//  Created by Ajay Kumar Singh on 11/24/16.
//  Copyright © 2016 Zendesk. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CLP_MainVMDataSet : NSObject

@end
