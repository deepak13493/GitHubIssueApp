//
//  ModelVMTest.m
//  CodingSkillTest
//
//  Created by Ajay Kumar Singh on 12/2/16.
//
//

#import <XCTest/XCTest.h>
#import "ModelVM.h"

@interface ModelVMTest : XCTestCase
 @property (nonatomic,strong) ModelVM *modelVM;

@end

@implementation ModelVMTest

- (void)setUp {
    [super setUp];
    self.modelVM = [[ModelVM alloc]init];

    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample {
    // This is an example of a functional test case.
    // Use XCTAssert and related functions to verify your tests produce the correct results.
}

- (void)testPerformanceExample {
    // This is an example of a performance test case.
    [self measureBlock:^{
        // Put the code you want to measure the time of here.
    }];
}
- (void)testForModelDatasourceValidation {
    XCTestExpectation *readyExpectation = [self expectationWithDescription:@"Model data fetching test"];
    NSString *manufacturedUniqueID = @"107"; // Hard code for testing
    
    [self.modelVM getModelDataForManufacturer:manufacturedUniqueID page:0 pageSize:10 onCompletion:^{
        
        NSInteger selectedRowIndex = 1; // Hard code:- Tap on 6 pos row by user so we can check whether it is giving accurate result or not
        
        NSInteger rowCount = [self.modelVM getAllCountOfModelData];
        NSString *modelName = [self.modelVM getModelNameForRow:selectedRowIndex];
        NSString *modelUniqueID = [self.modelVM getModelUniqueIdForRow:selectedRowIndex];
        if (rowCount == 0 || selectedRowIndex > rowCount) {
            XCTAssertNil(modelName,@"Model name shoulb be nil for no value in data source");
            XCTAssertNil(modelUniqueID,@"Model unique ID shoulb be nil for no value in data source");
        } else if (selectedRowIndex < rowCount) {
            XCTAssertNotNil(modelName,@"Model name should not be nil for any rowcount");
            XCTAssertNotNil(modelUniqueID,@"Model unique ID should not be nil for any rowcount");
        }

        [readyExpectation fulfill];

    } didFailWithError:^(ErrorResponse *error) {
        if ([error isKindOfClass:[ErrorResponse class]]) {
            XCTAssertNotNil(error.errorMessage,@" Should handled with valid error message");
        } else {
            XCTFail(@"Invalid error response");
        }
        [readyExpectation fulfill];
    }];
     
    [self waitForExpectationsWithTimeout:5 handler:^(NSError * _Nullable error) {
        NSLog(@"Error of long time consuming task... %@", error);
    }];
    
}
@end
