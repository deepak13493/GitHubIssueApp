//
//  CustomTableViewCell.m
//  CodingSkillTest


#import "CustomTableViewCell.h"

@interface CustomTableViewCell()
@end

@implementation CustomTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
#pragma mark - Update Cell UI

- (void)updateCellInformationByCellName:(NSString*)name andCellUniqueId:(NSString *)cellID {
    self.cellName.text = name;
    self.cellUniqueID = cellID;
}

@end
