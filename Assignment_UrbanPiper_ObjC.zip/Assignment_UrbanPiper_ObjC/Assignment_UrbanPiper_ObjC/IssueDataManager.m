//
//  IssueDataManager.m
//  Assignment_UrbanPiper_ObjC
//
//  Created by Bhagyashree on 22/11/16.
//  Copyright © 2016 Bhagyashree. All rights reserved.
//

#import "IssueDataManager.h"
#import "IssueDataBaseHelper.h"



@implementation IssueDataManager


-(void) fetch: (id) data{
    
    NSURL *baseUrl = [NSURL URLWithString:@"https://api.github.com/repos/crashlytics/secureudid/issues"];
    _issueData = data;
    _userDefault = [NSUserDefaults standardUserDefaults];
    Issue *issues = [self getAllCachedIssues];
    
    NSString *timeStamp = [_userDefault valueForKey:@"timeStamp"];
    if (issues) {
        // to do
        
    }
    
    
}


-(void) getAllData:(IssueContainer *)data{
    if (data) {
        IssueDataBaseHelper *issueDataHelper = [[IssueDataBaseHelper alloc]init];
        int total = [issueDataHelper replaceAllWithNew:data];
        [_userDefault setObject:[NSDate date] forKey:@"timeStamp"];
        if (total > 0) {
            // To Do
            _issueData = [issueDataHelper getIssues];
        }
    }
    else{
        _issueData = nil;
    }
}

-(Issue*) getAllCachedIssues{
    IssueDataBaseHelper *issueDataHelper = [[IssueDataBaseHelper alloc]init];
    return issueDataHelper.getIssues;
}

@end
