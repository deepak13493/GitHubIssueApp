//
//  CLPErrorResponse.h
//  ZendeskExercise
//
//  Created by Ajay Kumar Singh on 11/24/16.
//  Copyright © 2016 Zendesk. All rights reserved.
//


/*************
 
 This common custom ErrorResponse class. If any error will occur from server side we can make our own object with the appropriate message and show them to viewcontroller.
 
 **************/

#import <Foundation/Foundation.h>

@interface CLP_ErrorResponse : NSObject

@property(nonatomic,retain)NSString *errorCode;
@property (nonatomic,retain) NSString *errorMessage;

@end
