//
//  DataManager.h
//  CodingSkillTest
//
//  Created by Ajay Kumar Singh on 11/30/16.
//
//

#import <Foundation/Foundation.h>
#import "ErrorResponse.h"
#import "Manufacturer.h"
#import "Model.h"
#import "Year.h"

@interface DataManager : NSObject

+ (id)sharedManager;

- (void)getManufacturerDataForPage:(NSInteger)page pageSize:(NSInteger)pageSize onCompletion:(void (^)(Manufacturer *responseData))onCompletion didFailWithError:(void (^)(ErrorResponse *error))failedWithError;

- (void)getModelDataForManufacturer:(NSString *)manufacturerID page:(NSInteger)page pageSize:(NSInteger)pageSize onCompletion:(void (^)(Model *responseData))onCompletion didFailWithError:(void (^)(ErrorResponse *error))failedWithError;

- (void)getYearlDataForManufacturer:(NSString *)manufacturerID andMainTYpe:(NSString*)maintype onCompletion:(void (^)(Year *responseData))onCompletion didFailWithError:(void (^)(ErrorResponse *error))failedWithError;

@end
