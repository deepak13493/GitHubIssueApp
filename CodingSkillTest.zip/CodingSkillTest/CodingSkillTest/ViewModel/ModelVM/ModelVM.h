//
//  ModelVM.h
//  CodingSkillTest
//
//  Created by Ajay Kumar Singh on 11/30/16.
//
//

#import <Foundation/Foundation.h>
#import "ErrorResponse.h"


@interface ModelVM : NSObject

@property(nonatomic, assign) BOOL isSearchingEnabled;
@property (nonatomic, strong) NSString *selectedModelName;
@property (nonatomic, strong) NSString *selectedModelUniqueID;

- (NSInteger)getAllCountOfModelData;
- (NSString*)getModelNameForRow:(NSInteger)row;
- (NSString *)getModelUniqueIdForRow:(NSInteger)row;

- (void)getModelDataForManufacturer:(NSString *)manufacturerID page:(NSInteger)page pageSize:(NSInteger)pageSize onCompletion:(void (^)())onCompletion didFailWithError:(void (^)(ErrorResponse *error))failedWithError;

- (NSArray*)filterModelNameForSearchString:(NSString*)searchString;
@end
