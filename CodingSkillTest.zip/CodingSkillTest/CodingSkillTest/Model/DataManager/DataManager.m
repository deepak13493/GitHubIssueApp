//
//  DataManager.m
//  CodingSkillTest
//

#import "DataManager.h"
#import "NetworkManager.h"
#import "DataSerializer.h"

@implementation DataManager

/*
    DataManager is sharedInstance class so any other class can fetch or retrieve already stored data or pulled data from server.
 */

+ (id)sharedManager {
    static DataManager *sharedDataManager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedDataManager = [[self alloc] init];
    });
    return sharedDataManager;
}

/*
    Function to get Manufacturer Data for page value
*/

- (void)getManufacturerDataForPage:(NSInteger)page pageSize:(NSInteger)pageSize onCompletion:(void (^)(Manufacturer *responseData))onCompletion didFailWithError:(void (^)(ErrorResponse *error))failedWithError {
    NetworkManager *requestData = [[NetworkManager alloc]init];
    
    [requestData getManufacturerDataForPage:page pageSize:pageSize onCompletion:^(id responseData) {
        Manufacturer *manufact = [DataSerializer getSerializedDataOfMaufacturerResponseData:responseData];
        onCompletion(manufact);
    } didFailWithError:^(ErrorResponse *error) {
        failedWithError(error);
    }];
}

/*
    Function to get Model data for selected manufacturer name
*/

- (void)getModelDataForManufacturer:(NSString *)manufacturerID page:(NSInteger)page pageSize:(NSInteger)pageSize onCompletion:(void (^)(Model *responseData))onCompletion didFailWithError:(void (^)(ErrorResponse *error))failedWithError {
    NetworkManager *requestData = [[NetworkManager alloc]init];
    
    [requestData getModelDataForManufacturer:manufacturerID page:page pageSize:pageSize onCompletion:^(id responseData) {
        Model *manufact = [DataSerializer getSerializedDataOfModelResponseData:responseData];
        onCompletion(manufact);
    } didFailWithError:^(ErrorResponse *error) {
        failedWithError(error);
    }];

}

/*
    Function to get Built date for selected Many=ufacturer and Model name
*/

- (void)getYearlDataForManufacturer:(NSString *)manufacturerID andMainTYpe:(NSString*)maintype onCompletion:(void (^)(Year *responseData))onCompletion didFailWithError:(void (^)(ErrorResponse *error))failedWithError {
    NetworkManager *requestData = [[NetworkManager alloc]init];
    
    [requestData getYearlDataForManufacturer:manufacturerID andMainTYpe:maintype onCompletion:^(id responseData) {
        Year *yearData = [DataSerializer getSerializedDataOfYearResponseData:responseData];
        onCompletion(yearData);
    } didFailWithError:^(ErrorResponse *error) {
        failedWithError(error);
    }];
}
@end
