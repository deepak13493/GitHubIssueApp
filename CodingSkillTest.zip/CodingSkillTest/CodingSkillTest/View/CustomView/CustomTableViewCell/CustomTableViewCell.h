//
//  CustomTableViewCell.h
//  CodingSkillTest

#import <UIKit/UIKit.h>

@interface CustomTableViewCell : UITableViewCell

@property (nonatomic, weak) IBOutlet UILabel *cellName;
@property (nonatomic, strong) NSString *cellUniqueID;

- (void)updateCellInformationByCellName:(NSString*)name andCellUniqueId:(NSString *)cellID;

@end
