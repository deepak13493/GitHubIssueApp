//
//  CLPDataManager.m
//  ZendeskExercise
//
//  Created by Ajay Kumar Singh on 11/24/16.
//  Copyright © 2016 Zendesk. All rights reserved.
//

#import "CLP_DataManager.h"
#import "CLP_NetworkManager.h"
#import "CLP_DataSerializer.h"

@implementation CLP_DataManager


+ (id)sharedManager {
    static CLP_DataManager *sharedDataManager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedDataManager = [[self alloc] init];
    });
    return sharedDataManager;
}

- (void)getAllTickets:(void (^)(NSArray *responseData))onCompletion didFailWithError:(void (^)(CLP_ErrorResponse *error))failedWithError {
   
    CLP_NetworkManager *requestData = [[CLP_NetworkManager alloc]init];
    
    [requestData getAllTickets:^(id responseData) {
        NSArray *allTickets = [CLP_DataSerializer serializeAllTicketsForResponseData:responseData];
        onCompletion(allTickets);
    } didFailWithError:^(CLP_ErrorResponse *error) {
        failedWithError(error);
    }];
}

@end
