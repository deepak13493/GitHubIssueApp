//
//  IssueDataManager.h
//  Assignment_UrbanPiper_ObjC
//
//  Created by Bhagyashree on 22/11/16.
//  Copyright © 2016 Bhagyashree. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Issue+CoreDataClass.h"
#import "IssueContainer.h"



@interface IssueDataManager : NSObject

@property (nonatomic, strong) Issue *issueData;
@property (nonatomic, strong) NSUserDefaults *userDefault;


-(void) getAllData :(IssueContainer*)data;
-(void) fetch: (id) data;


@end
