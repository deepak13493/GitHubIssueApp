//
//  NetworkManager.m
//  CodingSkillTest


#import "NetworkManager.h"
#import "NetworkOperation.h"
#import "Constant.h"

@implementation NetworkManager

/*
    Function to get Manufacturer Data for page value
*/

- (void)getManufacturerDataForPage:(NSInteger)page pageSize:(NSInteger)pageSize onCompletion:(void (^)(id responseData))onCompletion didFailWithError:(void (^)(ErrorResponse *error))failedWithError {
    NSString *urlString = [kBaseURL stringByAppendingString:kManufacturerWebServiceURL];
    NSString *urlVal = [NSString stringWithFormat:@"%@page=%ld&pageSize=%ld&wa_key=%@",urlString,(long)page,(long)pageSize,kWAKey];
    NSURL *url = [NSURL URLWithString:[urlVal stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]]];
    NetworkOperation *networkOperation = [[NetworkOperation alloc]initWithURL:url];
    networkOperation.completionBlock = onCompletion;
    networkOperation.errorBlock = failedWithError;
    [networkOperation startSessionDataTask];
}

/*
    Function to get Model data for selected manufacturer name
*/

- (void)getModelDataForManufacturer:(NSString *)manufacturerUniqueID page:(NSInteger)page pageSize:(NSInteger)pageSize onCompletion:(void (^)(id responseData))onCompletion didFailWithError:(void (^)(ErrorResponse *error))failedWithError {
    NSString *urlString = [kBaseURL stringByAppendingString:kModelWebServiceURL];
    NSString *urlVal = [NSString stringWithFormat:@"%@manufacturer=%@&page=%ld&pageSize=%ld&wa_key=%@",urlString,manufacturerUniqueID,(long)page,(long)pageSize,kWAKey];
    NSURL *url = [NSURL URLWithString:[urlVal stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]]];
    NetworkOperation *networkOperation = [[NetworkOperation alloc]initWithURL:url];
    networkOperation.completionBlock = onCompletion;
    networkOperation.errorBlock = failedWithError;
    [networkOperation startSessionDataTask];
}

/*
    Function to get Built date for selected Many=ufacturer and Model name
*/

- (void)getYearlDataForManufacturer:(NSString *)manufacturerID andMainTYpe:(NSString*)maintype onCompletion:(void (^)(id responseData))onCompletion didFailWithError:(void (^)(ErrorResponse *error))failedWithError {
    NSString *urlString = [kBaseURL stringByAppendingString:kYearWebServiceURL];
    NSString *urlVal = [NSString stringWithFormat:@"%@manufacturer=%@&main-type=%@&wa_key=%@",urlString,manufacturerID,maintype,kWAKey];
    NSURL *url = [NSURL URLWithString:[urlVal stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]]];
     NetworkOperation *networkOperation = [[NetworkOperation alloc]initWithURL:url];
    networkOperation.completionBlock = onCompletion;
    networkOperation.errorBlock = failedWithError;
    [networkOperation startSessionDataTask];
 }
@end
