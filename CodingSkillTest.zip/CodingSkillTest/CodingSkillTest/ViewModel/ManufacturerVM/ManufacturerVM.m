//
//  ManufacturerVM.m
//  CodingSkillTest
//
//  Created by Ajay Kumar Singh on 11/30/16.
//
//

#import "ManufacturerVM.h"
#import "DataManager.h"
#import "CommonModelClass.h"

@interface ManufacturerVM ()

@property (nonatomic, strong) NSMutableArray *manufacturerStoredData;
@property (nonatomic, assign) NSInteger totalPageCount;


@end

@implementation ManufacturerVM

-(instancetype)init {
    if (self = [super init]) {
        self.manufacturerStoredData = [[NSMutableArray alloc]init];
    }
    return self;
}

- (void)getManufacturerDataForPage:(NSInteger)page pageSize:(NSInteger)pageSize onCompletion:(void (^)())onCompletion didFailWithError:(void (^)(ErrorResponse *error))failedWithError {
    
    if ([self.manufacturerStoredData count] > 0) {
        [self.manufacturerStoredData removeAllObjects];
    }
    
    DataManager *dataManager = [DataManager sharedManager];
    __weak ManufacturerVM *weakSelf = self;
    
    [dataManager getManufacturerDataForPage:page pageSize:pageSize onCompletion:^(Manufacturer *manufacturersData) {
        
        for (NSDictionary *eachData in manufacturersData.manufacturerDetails) {
            NSString *keyName = [[eachData allKeys]objectAtIndex:0];
            NSString *value = [eachData objectForKey:keyName];
            CommonModelClass *eachManufacturerData = [[CommonModelClass alloc]init];
            eachManufacturerData.name = value;
            eachManufacturerData.uniqueID = keyName;
            [weakSelf.manufacturerStoredData addObject:eachManufacturerData];
        }
        weakSelf.totalPageCount = manufacturersData.totalPageCount;
//        weakSelf.pageSize = manufacturersData.pageSize;
        onCompletion();
    } didFailWithError:^(ErrorResponse *error) {
        failedWithError(error);
    }];
}

#pragma mark - Public helper function

- (NSInteger)getAllManufacturersCount {
    return [self.manufacturerStoredData count];
}

/*
    Function to get manufacturer name
*/
- (NSString*)getManufacturerNameForRow:(NSInteger)row {
    if ([self.manufacturerStoredData count] > 0 && row < [self.manufacturerStoredData count]) {
        CommonModelClass *manufacturerData  = (CommonModelClass*)[self.manufacturerStoredData objectAtIndex:row];
        return manufacturerData.name;
    }
    return nil;
}

/*
    Function to get manufacturer unique ID
 */

- (NSString *)getManufacturerUniqueIDForRow:(NSInteger)row {
    if ([self.manufacturerStoredData count] > 0 && row < [self.manufacturerStoredData count]) {
        CommonModelClass *manufacturerData  =  (CommonModelClass*)[self.manufacturerStoredData objectAtIndex:row];
        return manufacturerData.uniqueID;
    }
    return nil;
}

/*
    Function to get total page count
*/

- (NSInteger)getTotalPageCount {
    return self.totalPageCount;
}

@end
