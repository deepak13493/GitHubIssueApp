//
//  CLPTicket.m
//  ZendeskExercise
//
//  Created by Ajay Kumar Singh on 11/24/16.
//  Copyright © 2016 Zendesk. All rights reserved.
//

#import "CLP_Ticket.h"

@implementation CLP_Ticket

@end
