//
//  IssueDataBaseHelper.m
//  Assignment_UrbanPiper_ObjC
//
//  Created by Bhagyashree on 22/11/16.
//  Copyright © 2016 Bhagyashree. All rights reserved.
//

#import "IssueDataBaseHelper.h"

@implementation IssueDataBaseHelper

@end
