//
//  DataSerializer.h
//  CodingSkillTest
//
//  Created by Ajay Kumar Singh on 11/30/16.
//
//

#import <Foundation/Foundation.h>
#import "Manufacturer.h"
#import "Model.h"
#import "Year.h"

@interface DataSerializer : NSObject

+ (Manufacturer*)getSerializedDataOfMaufacturerResponseData:(NSData*)responseData;

+ (Model*)getSerializedDataOfModelResponseData:(NSData*)responseData;

+ (Year*)getSerializedDataOfYearResponseData:(NSData*)responseData;

@end
