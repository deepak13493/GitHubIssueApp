//
//  ErrorResponse.m
//  CodingSkillTest
//
//  Created by Ajay Kumar Singh on 11/30/16.
//
//

#import "ErrorResponse.h"

@implementation ErrorResponse

@end
