//
//  Year.m
//  CodingSkillTest
 

#import "Year.h"

@implementation Year

@end
