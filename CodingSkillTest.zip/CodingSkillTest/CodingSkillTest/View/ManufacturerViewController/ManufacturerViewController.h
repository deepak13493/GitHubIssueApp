//
//  ManufacturerViewController.h
//  CodingSkillTest


#import <UIKit/UIKit.h>

@interface ManufacturerViewController : UIViewController

@end
