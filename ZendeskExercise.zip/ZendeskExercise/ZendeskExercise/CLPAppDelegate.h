//
//  CLPAppDelegate.h
//  Zendesk Exercise
//

#import <UIKit/UIKit.h>

@interface CLPAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
