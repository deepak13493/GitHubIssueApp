//
//  DataSerializer.m
//  CodingSkillTest


#import "DataSerializer.h"
#import "Constant.h"

@implementation DataSerializer

/*
    Function get serialized data for Manufacturer response data
*/

+ (Manufacturer*)getSerializedDataOfMaufacturerResponseData:(NSData*)responseData {
    if (responseData == nil) {
        return nil;
    }
    NSError *jsonError = nil;
    NSDictionary *jsonObject = [NSJSONSerialization JSONObjectWithData:responseData options:kNilOptions error:&jsonError];
    NSDictionary *manufacturersWKDA = [jsonObject objectForKey:kWKDA];
    NSMutableArray *allManufacturer = [[NSMutableArray alloc]init];
    [manufacturersWKDA enumerateKeysAndObjectsUsingBlock:^(id  _Nonnull key, id  _Nonnull obj, BOOL * _Nonnull stop) {
        NSDictionary *dict = @{key : obj};
        [allManufacturer addObject:dict];
    }];
    Manufacturer *manufacturerData = [[Manufacturer alloc]init];
    manufacturerData.pageSize = [[jsonObject objectForKey:kPageSize]integerValue];
    manufacturerData.totalPageCount = [[jsonObject objectForKey:kTotalPageCount]integerValue];
    manufacturerData.manufacturerDetails = [NSArray arrayWithArray:allManufacturer];
    
    return manufacturerData;
}

/*
    Function get serialized data for Model response data
 */


+ (Model*)getSerializedDataOfModelResponseData:(NSData*)responseData {
    if (responseData == nil) {
        return nil;
    }
    NSError *jsonError = nil;
    NSDictionary *jsonObject = [NSJSONSerialization JSONObjectWithData:responseData options:kNilOptions error:&jsonError];
    NSDictionary *manufacturersWKDA = [jsonObject objectForKey:kWKDA];
    NSMutableArray *allModela = [[NSMutableArray alloc]init];
    [manufacturersWKDA enumerateKeysAndObjectsUsingBlock:^(id  _Nonnull key, id  _Nonnull obj, BOOL * _Nonnull stop) {
        NSDictionary *dict = @{key : obj};
        [allModela addObject:dict];
    }];
    Model *modelData = [[Model alloc]init];
    modelData.pageSize = [[jsonObject objectForKey:kPageSize]integerValue];
    modelData.totalPageCount = [[jsonObject objectForKey:kTotalPageCount]integerValue];
    modelData.modelDetails = [NSArray arrayWithArray:allModela];
    
    return modelData;

}

/*
    Function get serialized data for Built date response data
 */


+ (Year*)getSerializedDataOfYearResponseData:(NSData*)responseData {
    if (responseData == nil) {
        return nil;
    }
    NSError *jsonError = nil;
    NSDictionary *jsonObject = [NSJSONSerialization JSONObjectWithData:responseData options:kNilOptions error:&jsonError];
    NSDictionary *manufacturersWKDA = [jsonObject objectForKey:kWKDA];
    NSMutableArray *allModela = [[NSMutableArray alloc]init];
    [manufacturersWKDA enumerateKeysAndObjectsUsingBlock:^(id  _Nonnull key, id  _Nonnull obj, BOOL * _Nonnull stop) {
        NSDictionary *dict = @{key : obj};
        [allModela addObject:dict];
    }];
    Year *yearData = [[Year alloc]init];
    yearData.yearDetails = [NSArray arrayWithArray:allModela];
    return yearData;
}

@end
