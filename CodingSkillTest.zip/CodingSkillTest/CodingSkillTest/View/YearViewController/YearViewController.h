//
//  YearViewController.h
//  CodingSkillTest


#import <UIKit/UIKit.h>
#import "ModelVM.h"
#import "ManufacturerVM.h"

@interface YearViewController : UIViewController

@property (nonatomic, strong) ModelVM *modelReferenceVM;
@property (nonatomic, strong) ManufacturerVM *manufaturerReferenceVM;

@end
