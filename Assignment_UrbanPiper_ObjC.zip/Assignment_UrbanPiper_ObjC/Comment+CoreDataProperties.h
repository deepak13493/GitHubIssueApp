//
//  Comment+CoreDataProperties.h
//  Assignment_UrbanPiper_ObjC
//
//  Created by Bhagyashree on 22/11/16.
//  Copyright © 2016 Bhagyashree. All rights reserved.
//  This file was automatically generated and should not be edited.
//

#import "Comment+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface Comment (CoreDataProperties)

+ (NSFetchRequest<Comment *> *)fetchRequest;

@property (nullable, nonatomic, copy) NSDate *createdDate;
@property (nullable, nonatomic, copy) NSString *details;
@property (nullable, nonatomic, copy) NSDate *updatedDate;
@property (nullable, nonatomic, copy) NSString *userName;
@property (nullable, nonatomic, retain) Issue *issue;

@end

NS_ASSUME_NONNULL_END
