//
//  CLPNetworkManager.m
//  ZendeskExercise
//
//  Created by Ajay Kumar Singh on 11/24/16.
//  Copyright © 2016 Zendesk. All rights reserved.
//

#import "CLP_NetworkManager.h"
#import "CLP_NetworkOperation.h"

#define SERVER_URL @"https://mxtechtest.zendesk.com/api/v2/views/39551161/tickets.json"

@implementation CLP_NetworkManager


- (void)getAllTickets:(void (^)(id responseData))onCompletion didFailWithError:(void (^)(CLP_ErrorResponse *error))failedWithError {
    CLP_NetworkOperation *networkOperation = [[CLP_NetworkOperation alloc]initWithURL:[NSURL URLWithString:SERVER_URL]];
    networkOperation.completionBlock = onCompletion;
    networkOperation.errorBlock = failedWithError;
    [networkOperation startSessionDataTask];
}

@end
