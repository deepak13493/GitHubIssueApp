//
//  CommentRequestResponseHandler.h
//  Assignment_UrbanPiper_ObjC
//
//  Created by Bhagyashree on 22/11/16.
//  Copyright © 2016 Bhagyashree. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CommentContainer.h"
#import "APIManager.h"


@class CommentRequestResponseHandler;


@protocol CommentRequestResponseHandlerDelegate<NSObject>

@required
- (void)getAllCommentsData:(CommentContainer*) commentData;

@end

@interface CommentRequestResponseHandler : NSObject

@property (assign, nonatomic) id<CommentRequestResponseHandlerDelegate> delegate;
@property (strong, nonatomic) APIManager *apiManager;

@property (strong, nonatomic) CommentContainer *commentContainerData;




@end
