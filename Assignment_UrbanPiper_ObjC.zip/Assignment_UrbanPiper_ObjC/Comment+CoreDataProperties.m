//
//  Comment+CoreDataProperties.m
//  Assignment_UrbanPiper_ObjC
//
//  Created by Bhagyashree on 22/11/16.
//  Copyright © 2016 Bhagyashree. All rights reserved.
//  This file was automatically generated and should not be edited.
//

#import "Comment+CoreDataProperties.h"

@implementation Comment (CoreDataProperties)

+ (NSFetchRequest<Comment *> *)fetchRequest {
	return [[NSFetchRequest alloc] initWithEntityName:@"Comment"];
}

@dynamic createdDate;
@dynamic details;
@dynamic updatedDate;
@dynamic userName;
@dynamic issue;

@end
