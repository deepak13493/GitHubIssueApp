//
//  IssueRequestResponseHandler.h
//  Assignment_UrbanPiper_ObjC
//
//  Created by Bhagyashree on 22/11/16.
//  Copyright © 2016 Bhagyashree. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "IssueContainer.h"
#import "APIManager.h"
#import "IssueDataParser.h"

@class IssueRequestResponseHandler;


@protocol IssueRequestResponseHandlerDelegate<NSObject>

@required
- (void)getAllData:(IssueContainer*) data;

@end



@interface IssueRequestResponseHandler : NSObject


@property (assign, nonatomic) id<IssueRequestResponseHandlerDelegate> delegate;
@property (strong, nonatomic) APIManager *apiManager;

@property (strong, nonatomic) IssueContainer *issueContainerData;

@end
