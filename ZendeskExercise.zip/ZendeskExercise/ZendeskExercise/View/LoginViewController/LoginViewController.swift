//
//  LoginViewController.swift
//  RentBycle
//
//  Created by Ajay Kumar Singh on 6/7/16.
//  Copyright © 2016 Ajay Kumar Singh. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var registrationSuccessLabel: UILabel!
    @IBOutlet weak var loginTitleLabel: UILabel!
    @IBOutlet weak var loginBackgroundView: UIView!
    @IBOutlet weak var bottomLayoutConstraint: NSLayoutConstraint!
    @IBOutlet weak var passwordTextfield: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var scrollView: UIScrollView!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.automaticallyAdjustsScrollViewInsets = false;
        NSNotificationCenter.defaultCenter().addObserver(self, selector: Selector("keyboardWillAppear:"), name: UIKeyboardWillShowNotification, object: nil)
        NSNotificationCenter.defaultCenter().addObserver(self, selector: Selector("keyboardWillHide:"), name: UIKeyboardWillHideNotification, object: nil)
        
        self.loginBackgroundView.alpha = 0.8
        self.loginBackgroundView.layer.cornerRadius = 5
        
         // Do any additional setup after loading the view.
    }
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBarHidden = true
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    /*
        Remove all set observer
    */
    override func viewDidDisappear(animated: Bool) {
        super.viewDidDisappear(animated)
        NSNotificationCenter.defaultCenter().removeObserver(self, name: UIKeyboardWillShowNotification, object: nil)
        NSNotificationCenter.defaultCenter().removeObserver(self, name: UIKeyboardWillHideNotification, object: nil)

    }
    
    // MARK: IBAction method
    /*
        IBaction to listen Login button clicked
    */
    @IBAction func didLoginButtonClicked(sender: AnyObject) {
        if (Reachability.hasConnectivity() == false) {
            self.showAlert(Constants.networkConenctionError)
        }
        
        // Changing title and returing only
        if self.loginTitleLabel.text == "Registration" {
            self.loginTitleLabel.text = "Login"
            return
        }
        
        print(" Login button clicked ");
        
        // Check login form validation
        if self.validateLoginForm() {
            let userDetails:NSDictionary = [
                "email" : self.emailTextField.text!,
                "password":self.passwordTextfield.text!
            ]
            
            // Call to authorization of users, web service call
            self.authenticateUserWithDetails(userDetails)
        }
    }
    /*
        IBaction to listen Registration button clicked and it will call registration api for new regsitration
    */

    @IBAction func didRegistrationButtonClicked(sender: AnyObject) {
        if (Reachability.hasConnectivity() == false) {
            self.showAlert(Constants.networkConenctionError)
        }

        // Changing title and returing only
        if self.loginTitleLabel.text == "Login" {
            self.loginTitleLabel.text = "Registration"
            return
        }
        
        print(" registration button clicked ");
        
        // cheking validation of form
        if self.validateLoginForm() {
            let userDetails:NSDictionary = [
                "email" : self.emailTextField.text!,
                "password":self.passwordTextfield.text!
            ]
            self.registration(userDetails)
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    // MARK: UITextfield delegate
    func textFieldShouldEndEditing(textField: UITextField) -> Bool {
        self.resignKeyboard()
        return true
    }
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        self.resignKeyboard()
        return true
    }
    
    // MARK: Private funtion
    
    // function to use dismiss of keyboard
    func resignKeyboard() {
            self.emailTextField.resignFirstResponder()
            self.passwordTextfield.resignFirstResponder()
    }
    
    // func to call registration api web service
    func registration(userDetails: NSDictionary?) {
        
        if let data = userDetails  {
            let urlString = Constants.localhost .stringByAppendingString(Constants.registrationURL)
            let url = NSURL(string: urlString)
            var userData: NSData?
            do
            {
                userData = try NSJSONSerialization.dataWithJSONObject(data, options: NSJSONWritingOptions.PrettyPrinted)
            }catch{}
            
            let request = RequestHandler.init(urlParam: url!, httpBody: userData!)
            let loginRequest = NetworkOperation.init(requestParam: request)
            
            loginRequest.registration({ (responseData) -> Void in
                    self.emailTextField.text = "";
                    self.passwordTextfield.text = ""
                    self.registrationSuccessLabel.hidden = false
                }) { (error) -> Void in
                    let responseError = error as ResponseError?
                    self.showAlert(responseError?.errorMessage)
            }
        }
    }
    
    // func to call Login web service api
    func authenticateUserWithDetails(userDetails: NSDictionary?) {
        if let data = userDetails  {
            let urlString = Constants.localhost .stringByAppendingString(Constants.loginURL)
            let url = NSURL(string: urlString)
            var userData: NSData?
            do
            {
                userData = try NSJSONSerialization.dataWithJSONObject(data, options: NSJSONWritingOptions.PrettyPrinted)
            }catch{
                print("Json Serialization Error")
            }
            
            let request = RequestHandler.init(urlParam: url!, httpBody: userData!)
            let loginRequest = NetworkOperation.init(requestParam: request)
            
            loginRequest.getLoginAuthentication({ (responseData) -> Void in
                DataManager.sharedInstance.saveLoginAuthToken(responseData)
                self.performSegueWithIdentifier("MapSegue", sender: nil)
                
            }) { (error) -> Void in
                    let responseError = error as ResponseError?
                    self.showAlert(responseError?.errorMessage)
            }
        }
    }
    
    /*
        Show alert error message while input of any wrong action
    */
    
    func showAlert(alertError:NSString?) {
        let alert = UIAlertController(title: "Error", message: alertError as String?, preferredStyle: UIAlertControllerStyle.Alert)
        // add an action (button)
        alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.Default, handler: nil))
        // show the alert
        self.presentViewController(alert, animated: true, completion: nil)
    }
    
    /*
        Validation of form private function
    */
    
    func validateLoginForm()->Bool {
        let emailFieldError = self.validateEmailTextField()
        let passwordTextFieldError = self.validatePasswordextField()
        if emailFieldError.length > 0 {
            [self .showAlert(emailFieldError)]
            return false
        } else if passwordTextFieldError.length > 0  {
            [self .showAlert(passwordTextFieldError)]
            return false;
        } else {
            return true;
        }
    }
   
    /*
        Validation of Email textfield, private function
    */
    
    func validateEmailTextField()->NSString {
        let isEmailTextEmpty = self.emailTextField.text?.isEmpty
        if isEmailTextEmpty == true {
            return "Please enter email!"
        } else {
            let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
            let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
            let isCorrectEmailID = emailTest.evaluateWithObject(self.emailTextField.text)
            return (isCorrectEmailID == false) ? "Email format is wrong, please check it!" : ""
        }
    }
    
    /*
        Validation of Password textfield, private function
    */
    

    func validatePasswordextField()->NSString {
        let isPasswordTextEmpty = self.passwordTextfield.text?.isEmpty
         if isPasswordTextEmpty == true {
            return "Please enter password!"
        }
        return ""
    }
    
    // MARK: - Keyboard Observer
    func keyboardWillAppear(notification:NSNotification) {
        print("Keyboard appeared")
//        let userInfo:NSDictionary = notification.userInfo!
//        let keyboardFrame:NSValue = userInfo.valueForKey(UIKeyboardFrameEndUserInfoKey) as! NSValue
//        let keyboardRectangle = keyboardFrame.CGRectValue()
//        let keyboardHeight = keyboardRectangle.height
////        print("Bottom height \(self.bottomLayoutConstraint.constant)")
//         self.bottomLayoutConstraint.constant = keyboardHeight;
////        self.scrollView.contentSize.height = self.scrollView.contentSize.height + keyboardHeight
    }
    
    func keyboardWillHide(notification:NSNotification) {
//        self.bottomLayoutConstraint.constant = 207;
        print("Keyboard hidden")
    }
}
