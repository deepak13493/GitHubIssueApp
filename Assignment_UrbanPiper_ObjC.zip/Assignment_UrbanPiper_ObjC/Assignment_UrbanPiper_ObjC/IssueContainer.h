//
//  IssueContainer.h
//  Assignment_UrbanPiper_ObjC
//
//  Created by Bhagyashree on 22/11/16.
//  Copyright © 2016 Bhagyashree. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface IssueContainer : NSObject

@property (nonatomic, strong) NSString *title;
@property (nonatomic, strong) NSString *createdDate;
@property (nonatomic, strong) NSString *updatedDate;
@property (nonatomic, strong) NSString *state;
@property (nonatomic, strong) NSString *details;
@property (nonatomic, strong) NSString *comments_url;

@end
