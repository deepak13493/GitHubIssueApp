//
//  Year.h
//  CodingSkillTest
 

#import <Foundation/Foundation.h>

@interface Year : NSObject

@property (nonatomic, strong) NSArray *yearDetails;

@end
