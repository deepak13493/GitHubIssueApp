//
//  APIManager.h
//  Assignment_UrbanPiper_ObjC
//
//  Created by Bhagyashree on 22/11/16.
//  Copyright © 2016 Bhagyashree. All rights reserved.
//

#import <Foundation/Foundation.h>


@class APIManager;

@protocol APIManagerDelegate <NSObject>

@required
-(void)response:(NSData*)data WithError:(NSError*)error;

@end


@interface APIManager : NSObject

@property (assign, nonatomic) id<APIManagerDelegate> apiManagerDelegate;

-(void)request :(NSString*)urlString;


@end
