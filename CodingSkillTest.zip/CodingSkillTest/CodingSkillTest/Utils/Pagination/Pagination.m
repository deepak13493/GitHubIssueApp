//
//  Pagination.m
//  TestCodingSkill


#import "Pagination.h"

#define MaximumButtonsInEachSlot 3

@interface Pagination ()

@property (nonatomic, weak) IBOutlet UIButton *previousButton;
@property (nonatomic, weak) IBOutlet UIButton *nextButton;

@property (nonatomic, weak) IBOutlet UIButton *buttonFirst;
@property (nonatomic, weak) IBOutlet UIButton *buttonSecond;
@property (nonatomic, weak) IBOutlet UIButton *buttonThird;

@property (nonatomic, assign) NSInteger totalRecords;
@property (nonatomic, assign) NSInteger currentSlotNumber;
@property (nonatomic, assign) NSInteger lastSlotNumber;
@property (nonatomic, assign) NSInteger buttonsInLastSlot;
@property (nonatomic, assign) NSInteger currentButtonIndex;

@end

@implementation Pagination

- (instancetype)initWithCoder:(NSCoder *)coder
{
    self = [super initWithCoder:coder];
    if (self) {
        [self initialSetup];
     }
    return self;
}

/*
    Function to initial setup
*/

- (void)initialSetup {
    self.currentSlotNumber = 1;
    self.currentButtonIndex = 0;
     
    dispatch_async(dispatch_get_main_queue(), ^{
        NSInteger buttonsInCurrentSlot = [self getNumberOfButtonsInslot:self.currentSlotNumber];
        switch (buttonsInCurrentSlot) {
            case 1:
                [self.previousButton setEnabled:NO];
                [self.nextButton setEnabled:NO];
                break;
            default:
                [self.previousButton setEnabled:NO];
                break;
        }
        [self updateButtonIndexText];
        [self updateSlotUI];
        [self highLightCurrentIndexButton:self.currentButtonIndex];
    });
}

/*
    Function to hide all views if total record are ZERO
*/

- (void)hideAndNoActionOnView {
    self.buttonFirst.hidden = YES;
    self.buttonSecond.hidden = YES;
    self.buttonThird.hidden = YES;
    self.nextButton.hidden = YES;
    self.previousButton.hidden = YES;
}

/*
    Functin to get total number of buttons in last page/slot
*/

- (NSInteger)getButtonsInLastSlot:(NSInteger)totalNumberOfRecord {
    if (totalNumberOfRecord <= 0) {
        return 0;
    }

     NSInteger moduloCal = ceil((CGFloat)(self.totalRecords % (self.numberOfRecordsInEachPage * MaximumButtonsInEachSlot))/self.numberOfRecordsInEachPage);
    return (moduloCal == 0) ? MaximumButtonsInEachSlot : moduloCal;
}

/*
    Function to get number/value of last slot
*/

- (NSInteger)getLastSlotValue:(NSInteger)totalNumberOfRecord {
    if (totalNumberOfRecord <= 0) {
        return 0;
    }
    NSInteger divisor = self.totalRecords / (self.numberOfRecordsInEachPage * MaximumButtonsInEachSlot);
     NSInteger moduloVal =  self.totalRecords % (self.numberOfRecordsInEachPage * MaximumButtonsInEachSlot);
    return (moduloVal > 0) ? divisor + 1 : divisor;
}

/*
    Call setter method of totalNumberPageCount to design change in pagination view. It will adjust/show counter data on view.
*/

- (void)setTotalPageCount:(NSInteger)totalPageCount {
    if (totalPageCount == 0) {
        [self hideAndNoActionOnView];
        return;
    }
    _totalPageCount = totalPageCount;
    self.totalRecords =  totalPageCount * self.numberOfRecordsInEachPage;
    self.lastSlotNumber = [self getLastSlotValue:self.totalRecords];
    self.buttonsInLastSlot = [self getButtonsInLastSlot:self.totalRecords];
    [self updateButtonIndexText];
    [self updateSlotUI];
    [self highLightCurrentIndexButton:self.currentButtonIndex];
}

/*
    Get total number of buttons in last slot, or else it will return maximum number of buttons which is 3 for this design.
*/

- (NSInteger)getNumberOfButtonsInslot:(NSInteger)slotValue {
    if (slotValue >= self.lastSlotNumber) {
        return self.buttonsInLastSlot;
    }
    
    return MaximumButtonsInEachSlot;
}

/*
    Update button text for each right or left pagination click
*/

- (void)updateButtonIndexText {
    NSInteger buttonsInCurrentSlot = [self getNumberOfButtonsInslot:self.currentSlotNumber];
    NSInteger initialIndexPointer = (self.currentSlotNumber - 1) * 3 + 1;
    
    for (NSInteger i = initialIndexPointer, buttonPointer =1; i < (initialIndexPointer + buttonsInCurrentSlot); i++, buttonPointer++) {
        switch (buttonPointer) {
            case 1:
                [UIView setAnimationsEnabled:NO];
                [self.buttonFirst setTitle:[NSString stringWithFormat:@"%ld",(long)i] forState:UIControlStateNormal];
                [self.buttonFirst layoutIfNeeded];
                [UIView setAnimationsEnabled:YES];
                break;
            case 2:
                [UIView setAnimationsEnabled:NO];
                [self.buttonSecond setTitle:[NSString stringWithFormat:@"%ld",(long)i] forState:UIControlStateNormal];
                [self.buttonSecond layoutIfNeeded];
                [UIView setAnimationsEnabled:YES];
                break;
            case 3:
                [UIView setAnimationsEnabled:NO];
                [self.buttonThird setTitle:[NSString stringWithFormat:@"%ld",(long)i] forState:UIControlStateNormal];
                [self.buttonThird layoutIfNeeded];
                [UIView setAnimationsEnabled:YES];
                break;
            default:
                break;
        }
    }
}

/*  
    Update Slot UI for any action
*/

- (void)updateSlotUI {
    NSInteger buttonsInCurrentSlot = [self getNumberOfButtonsInslot:self.currentSlotNumber];
    
    switch (buttonsInCurrentSlot) {
        case 1:
            self.buttonSecond.hidden = YES;
            self.buttonThird.hidden = YES;
            break;
        case 2:
            self.buttonThird.hidden = YES;
            break;
        default:
            self.buttonFirst.hidden = NO;
            self.buttonSecond.hidden = NO;
            self.buttonThird.hidden = NO;
            break;
    }
}

/*
    Function to highlight current index button
*/

- (void)highLightCurrentIndexButton:(NSInteger)currentIndex {
    switch (currentIndex) {
        case 0:
             [self enableHighLightForButton:self.buttonFirst];
             [self disableHighlightForButton:self.buttonSecond];
             [self disableHighlightForButton:self.buttonThird];
            break;
        case 1:
            [self disableHighlightForButton:self.buttonFirst];
            [self enableHighLightForButton:self.buttonSecond];
            [self disableHighlightForButton:self.buttonThird];
            break;
        case 2:
            [self disableHighlightForButton:self.buttonFirst];
            [self disableHighlightForButton:self.buttonSecond];
            [self enableHighLightForButton:self.buttonThird];
            break;
        default:
            break;
    }
}

#pragma mark -
/*
    Animation on button
*/

- (void)enableHighLightForButton:(UIButton*)selectedButton {
    [UIView animateWithDuration:0.5 animations:^{
        [selectedButton setBackgroundColor:[UIColor lightGrayColor]];
        [selectedButton setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    }];
 }

- (void)disableHighlightForButton:(UIButton*)notSelectedButton {
    [notSelectedButton setBackgroundColor:[UIColor blackColor]];
    [notSelectedButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
}

#pragma mark - IBAction

- (IBAction)didPreviousButtonClicked:(id)sender {
    self.currentButtonIndex--;
    
    if (self.currentButtonIndex < 0) {
        self.currentSlotNumber--;
        self.currentButtonIndex = [self getNumberOfButtonsInslot:self.currentSlotNumber] - 1;
        [self updateButtonIndexText];
        [self updateSlotUI];
    }
    if (self.currentSlotNumber <= 1 && self.currentButtonIndex <= 0) {
        [self.previousButton setEnabled:NO];
    }
    if (!self.nextButton.enabled) {
        [self.nextButton setEnabled:YES];
    }
    [self highLightCurrentIndexButton:self.currentButtonIndex];
    
    if ([self.paginationDelegate respondsToSelector:@selector(didPreviousButtonClicked:)]) {
        [self.paginationDelegate didPreviousButtonClicked:self];
    }
}

- (IBAction)didNextButtonClicked:(id)sender {
    
    self.currentButtonIndex++;
    
    if ((self.currentButtonIndex % 3) == 0) {
        self.currentSlotNumber++;
        self.currentButtonIndex = 0;
        [self updateButtonIndexText];
        [self updateSlotUI];
    }
    if (self.currentSlotNumber >= self.lastSlotNumber && self.currentButtonIndex == (self.buttonsInLastSlot - 1)) {
        [self.nextButton setEnabled:NO];
        self.currentSlotNumber = self.lastSlotNumber;
    }
    [self highLightCurrentIndexButton:self.currentButtonIndex];
    if (!self.previousButton.enabled) {
        [self.previousButton setEnabled:YES];
    }
    if ([self.paginationDelegate respondsToSelector:@selector(didNextButtonClicked:)]) {
        [self.paginationDelegate didNextButtonClicked:self];
    }
}

@end
