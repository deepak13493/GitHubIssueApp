//
//  CommentRequestResponseHandler.m
//  Assignment_UrbanPiper_ObjC
//
//  Created by Bhagyashree on 22/11/16.
//  Copyright © 2016 Bhagyashree. All rights reserved.
//

#import "CommentRequestResponseHandler.h"
#import "CommentDataParser.h"

@implementation CommentRequestResponseHandler

-(void)fetchCommentData : (NSString*) fromUrl{
    if (fromUrl) {
        _apiManager.apiManagerDelegate = self;
        [_apiManager request:fromUrl];
    }

}

- (void)response:(NSData*)data WithError:(NSError*)error{
    if (data) {
        CommentDataParser *commentDataParser;
        _commentContainerData = [commentDataParser parse:data];
        [_delegate getAllCommentsData:_commentContainerData];
    }
    else{
        [_delegate getAllCommentsData:nil];
    }
}

@end
