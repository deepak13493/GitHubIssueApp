//
//  NetworkManager.h
//  CodingSkillTest
 

#import <Foundation/Foundation.h>
#import "ErrorResponse.h"

@interface NetworkManager : NSObject

- (void)getManufacturerDataForPage:(NSInteger)page pageSize:(NSInteger)pageSize onCompletion:(void (^)(id responseData))onCompletion didFailWithError:(void (^)(ErrorResponse *error))failedWithError;

- (void)getModelDataForManufacturer:(NSString *)manufacturerID page:(NSInteger)page pageSize:(NSInteger)pageSize onCompletion:(void (^)(id responseData))onCompletion didFailWithError:(void (^)(ErrorResponse *error))failedWithError;

- (void)getYearlDataForManufacturer:(NSString *)manufacturerID andMainTYpe:(NSString*)maintype onCompletion:(void (^)(id responseData))onCompletion didFailWithError:(void (^)(ErrorResponse *error))failedWithError;

@end
