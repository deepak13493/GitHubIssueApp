//
//  ModelViewController.h
//  CodingSkillTest



#import <UIKit/UIKit.h>
#import "ManufacturerVM.h"

@interface ModelViewController : UIViewController

@property (nonatomic, strong) ManufacturerVM *manufaturerReferenceVM;

@end
