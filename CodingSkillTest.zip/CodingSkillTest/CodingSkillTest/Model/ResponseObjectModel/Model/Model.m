//
//  Model.m
//  CodingSkillTest
 

#import "Model.h"

@implementation Model

@end
