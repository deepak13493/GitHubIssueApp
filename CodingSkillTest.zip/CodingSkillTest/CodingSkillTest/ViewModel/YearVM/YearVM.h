//
//  YearVM.h
//  CodingSkillTest


#import <Foundation/Foundation.h>
#import "ErrorResponse.h"

@interface YearVM : NSObject

- (NSInteger)getAllYearDataCount;
- (NSString *)getYearNameForRow:(NSInteger)row;
- (NSString *)getYearUniqueIDForRow:(NSInteger)row;

- (void)getYearlDataForManufacturer:(NSString *)manufacturerID andMainTYpe:(NSString*)maintype onCompletion:(void (^)())onCompletion didFailWithError:(void (^)(ErrorResponse *error))failedWithError;

@end
