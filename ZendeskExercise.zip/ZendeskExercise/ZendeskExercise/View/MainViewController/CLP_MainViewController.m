//
//  CLPMainViewController.m
//  ZendeskExercise
//
//  Created by Ajay Kumar Singh on 11/24/16.
//  Copyright © 2016 Zendesk. All rights reserved.
//

#import "CLP_MainViewController.h"
#import "CLP_TicketTableTableViewController.h"

@interface CLP_MainViewController ()
@end

@implementation CLP_MainViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationController.navigationBar.hidden = NO;
    self.navigationItem.hidesBackButton = YES;

    CLP_TicketTableTableViewController* ticketVC = [self.storyboard instantiateViewControllerWithIdentifier:@"CLP_TicketTableTableViewController"];
      [self addChildViewController:ticketVC];
    [ticketVC didMoveToParentViewController:self];
    ticketVC.view.frame = self.view.frame;
    [self.view addSubview:ticketVC.view];
    // Do any additional setup after loading the view.
}
//
//- (void)didReceiveMemoryWarning {
//    [super didReceiveMemoryWarning];
//    // Dispose of any resources that can be recreated.
//}
//
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
