//
//  Model.h
//  CodingSkillTest
 

#import <Foundation/Foundation.h>

@interface Model : NSObject

@property (nonatomic, assign) NSInteger pageSize;
@property (nonatomic, assign) NSInteger totalPageCount;
@property (nonatomic, assign) NSInteger pageValue;
@property (nonatomic, strong) NSArray *modelDetails;

@end
