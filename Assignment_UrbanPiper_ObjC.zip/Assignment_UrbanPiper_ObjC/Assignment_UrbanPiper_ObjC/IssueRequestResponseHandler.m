//
//  IssueRequestResponseHandler.m
//  Assignment_UrbanPiper_ObjC
//
//  Created by Bhagyashree on 22/11/16.
//  Copyright © 2016 Bhagyashree. All rights reserved.
//

#import "IssueRequestResponseHandler.h"

@implementation IssueRequestResponseHandler

-(void)fetchCommentData : (NSString*) fromUrl{
    if (fromUrl) {
        _apiManager.apiManagerDelegate = self;
        [_apiManager request:fromUrl];
    }
    
}

- (void)response:(NSData*)data WithError:(NSError*)error{
    if (data) {
        IssueDataParser *issueDataParser;
        _issueContainerData = [issueDataParser parse:data];
        [_delegate getAllData:_issueContainerData];
    }
    else{
        [_delegate getAllData:nil];
    }
}

@end
