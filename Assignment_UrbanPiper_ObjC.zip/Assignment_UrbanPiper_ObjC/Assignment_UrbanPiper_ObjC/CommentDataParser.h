//
//  CommentDataParser.h
//  Assignment_UrbanPiper_ObjC
//
//  Created by Bhagyashree on 22/11/16.
//  Copyright © 2016 Bhagyashree. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "CommentContainer.h"

@interface CommentDataParser : NSObject
-(CommentContainer*) parse:(NSData *)forData;


@end
