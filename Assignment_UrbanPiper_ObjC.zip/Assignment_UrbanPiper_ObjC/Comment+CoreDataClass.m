//
//  Comment+CoreDataClass.m
//  Assignment_UrbanPiper_ObjC
//
//  Created by Bhagyashree on 22/11/16.
//  Copyright © 2016 Bhagyashree. All rights reserved.
//  This file was automatically generated and should not be edited.
//

#import "Comment+CoreDataClass.h"
#import "Issue+CoreDataClass.h"
@implementation Comment

@end
