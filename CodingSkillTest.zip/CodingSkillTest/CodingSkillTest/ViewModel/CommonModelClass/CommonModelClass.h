//
//  CommonModelClass.h
//  CodingSkillTest
 

#import <Foundation/Foundation.h>

@interface CommonModelClass : NSObject

@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSString *uniqueID;

@end
