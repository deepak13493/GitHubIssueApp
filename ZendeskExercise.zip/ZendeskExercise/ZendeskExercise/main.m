//
//  main.m
//  Zendesk Exercise
//

#import <UIKit/UIKit.h>

#import "CLPAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([CLPAppDelegate class]));
    }
}
