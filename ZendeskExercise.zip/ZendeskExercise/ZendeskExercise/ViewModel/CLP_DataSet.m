//
//  CLPDataSet.m
//  ZendeskExercise
//
//  Created by Ajay Kumar Singh on 11/24/16.
//  Copyright © 2016 Zendesk. All rights reserved.
//

#import "CLP_DataSet.h"
 #import "CLP_TicketVMDataSet.h"
#import "CLP_MainVMDataSet.h"

@interface CLP_DataSet ()

//@property (nonatomic, strong) CLP_MainVMDataSet *mainVMDataSet;
@property (nonatomic, strong) CLP_TicketVMDataSet *ticketVMDataSet;

@end

@implementation CLP_DataSet

//+ (id)sharedDataSet {
//    static CLP_DataSet *sharedDataSet = nil;
//    static dispatch_once_t onceToken;
//    dispatch_once(&onceToken, ^{
//        sharedDataSet = [[self alloc] init];
//    });
//    return sharedDataSet;
//}

- (instancetype)init {
    if (self = [super init]) {
        self.ticketVMDataSet = [[CLP_TicketVMDataSet alloc]init];
    }
    return self;
}

- (void)getAllTickets:(void (^)())onCompletion didFailWithError:(void (^)(CLP_ErrorResponse *error))failedWithError {
    
    [self.ticketVMDataSet getAllTickets:^(id responseData) {
        NSLog(@"All Data %@",responseData);
        onCompletion(nil);
    } didFailWithError:^(CLP_ErrorResponse *error) {
        NSLog(@"Data Error %@",error.errorMessage);
    }];
}

- (NSUInteger)getAllTicketsCount {
    return self.ticketVMDataSet.allTickets.count;
}

@end
