//
//  ManufacturerVMTest.m
//  CodingSkillTest
//
//  Created by Ajay Kumar Singh on 12/2/16.
//
//

#import <XCTest/XCTest.h>
#import "ManufacturerVM.h"
#import "ErrorResponse.h"

@interface ManufacturerVMTest : XCTestCase

@property (nonatomic,strong) ManufacturerVM *manufacturerVM;

@end

@implementation ManufacturerVMTest

- (void)setUp {
    [super setUp];
    
    self.manufacturerVM = [[ManufacturerVM alloc]init];    
    
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample {
    // This is an example of a functional test case.
    // Use XCTAssert and related functions to verify your tests produce the correct results.
}

- (void)testPerformanceExample {
    // This is an example of a performance test case.
    [self measureBlock:^{
        // Put the code you want to measure the time of here.
    }];
}
- (void)testForManufacturerDatasourceValidation {
    XCTestExpectation *readyExpectation = [self expectationWithDescription:@"Manufacture data fetching test"];
    
    [self.manufacturerVM getManufacturerDataForPage:0 pageSize:10 onCompletion:^{
        
        NSInteger selectedRowIndex = 5; // Hard code:- Tap on 6 pos row by user so we can check whether it is giving accurate result or not
        
        NSInteger rowCount = [self.manufacturerVM getAllManufacturersCount];
        NSString *manufacturerName = [self.manufacturerVM getManufacturerNameForRow:selectedRowIndex];
        NSString *manufacturerUniqueID = [self.manufacturerVM getManufacturerUniqueIDForRow:selectedRowIndex];
        if (rowCount == 0 || selectedRowIndex > rowCount) {
            XCTAssertNil(manufacturerName,@"Manufacturer name shoulb be nil for no value in data source");
            XCTAssertNil(manufacturerUniqueID,@"Manufacturer unique ID shoulb be nil for no value in data source");
        } else if (selectedRowIndex < rowCount) {
            XCTAssertNotNil(manufacturerName,@"Manufacturer name should not be nil for any rowcount");
            XCTAssertNotNil(manufacturerUniqueID,@"Manufacturer unique ID should not be nil for any rowcount");
        }
        
        [readyExpectation fulfill];
    } didFailWithError:^(ErrorResponse *error) {
        if ([error isKindOfClass:[ErrorResponse class]]) {
            XCTAssertNotNil(error.errorMessage,@" Should handled with valid error message");
        } else {
            XCTFail(@"Invalid error response");
        }
        [readyExpectation fulfill];

    }];
 
    [self waitForExpectationsWithTimeout:5 handler:^(NSError * _Nullable error) {
        NSLog(@"Error of long time consuming task... %@", error);
    }];
    
}
@end
