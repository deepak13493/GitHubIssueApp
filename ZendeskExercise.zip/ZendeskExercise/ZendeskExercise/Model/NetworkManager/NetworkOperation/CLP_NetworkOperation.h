//
//  CLPNetworkOperation.h
//  ZendeskExercise
//
//  Created by Ajay Kumar Singh on 11/24/16.
//  Copyright © 2016 Zendesk. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CLP_ErrorResponse.h"

@interface CLP_NetworkOperation : NSObject

@property (copy)void (^completionBlock)(NSData *responseData);
@property (copy)void (^errorBlock)(CLP_ErrorResponse *error);

- (instancetype)initWithURL:(NSURL*)url;
- (void)startSessionDataTask;

@end
