//
//  CLPTicketVMDataSet.m
//  ZendeskExercise
//
//  Created by Ajay Kumar Singh on 11/24/16.
//  Copyright © 2016 Zendesk. All rights reserved.
//

#import "CLP_TicketVMDataSet.h"
#import "CLP_DataManager.h"

@interface CLP_TicketVMDataSet ()
@property (nonatomic, strong, readwrite) NSArray *allTickets;
@end

@implementation CLP_TicketVMDataSet

-(instancetype)init {
    if (self = [super init]) {
        //init
    }
    return self;
}
//+ (id)sharedTicketDataSet {
//    static CLP_TicketVMDataSet *sharedTicketDataSet = nil;
//    static dispatch_once_t onceToken;
//    dispatch_once(&onceToken, ^{
//        sharedTicketDataSet = [[self alloc] init];
//    });
//    return sharedTicketDataSet;
//}

- (void)getAllTickets:(void (^)(NSArray *responseData))onCompletion didFailWithError:(void (^)(CLP_ErrorResponse *error))failedWithError {
        CLP_DataManager *dataManager = [CLP_DataManager sharedManager];
        [dataManager getAllTickets:^(NSArray *responseData) {
            NSLog(@"All Data %@",responseData);
            self.allTickets = [NSArray arrayWithArray:responseData];
            onCompletion(self.allTickets);
        } didFailWithError:^(CLP_ErrorResponse *error) {
            NSLog(@"Data Error %@",error.errorMessage);
            self.allTickets = nil;
        }];
}

@end
