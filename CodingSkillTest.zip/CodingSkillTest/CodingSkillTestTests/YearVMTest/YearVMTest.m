//
//  YearVMTest.m
//  CodingSkillTest
//
//  Created by Ajay Kumar Singh on 12/2/16.
//
//

#import <XCTest/XCTest.h>
#import "YearVM.h"

@interface YearVMTest : XCTestCase
@property (nonatomic,strong) YearVM *yearVM;

@end

@implementation YearVMTest

- (void)setUp {
    [super setUp];
    self.yearVM = [[YearVM alloc]init];

    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample {
    // This is an example of a functional test case.
    // Use XCTAssert and related functions to verify your tests produce the correct results.
}

- (void)testPerformanceExample {
    // This is an example of a performance test case.
    [self measureBlock:^{
        // Put the code you want to measure the time of here.
    }];
}

- (void)testForYearDatasourceValidation {
    XCTestExpectation *readyExpectation = [self expectationWithDescription:@"Year data fetching test"];
    NSString *manufacturedUniqueID = @"107"; // Hard code for testing
    NSString *mainType = @"Arnage"; // Hard coded string for testing
    
    
    [self.yearVM getYearlDataForManufacturer:manufacturedUniqueID andMainTYpe:mainType onCompletion:^{
        
        NSInteger selectedRowIndex = 1; // Hard code:- Tap on 6 pos row by user so we can check whether it is giving accurate result or not
        
        NSInteger rowCount = [self.yearVM getAllYearDataCount];
        NSString *yearName = [self.yearVM getYearNameForRow:selectedRowIndex];
        NSString *yearUniqueID = [self.yearVM getYearUniqueIDForRow:selectedRowIndex];
        if (rowCount == 0 || selectedRowIndex > rowCount) {
            XCTAssertNil(yearName,@"Year name shoulb be nil for no value in data source");
            XCTAssertNil(yearUniqueID,@"Year unique ID shoulb be nil for no value in data source");
        } else if (selectedRowIndex < rowCount) {
            XCTAssertNotNil(yearName,@"Year name should not be nil for any rowcount");
            XCTAssertNotNil(yearUniqueID,@"Year unique ID should not be nil for any rowcount");
        }
        
        [readyExpectation fulfill];
        
    } didFailWithError:^(ErrorResponse *error) {
        if ([error isKindOfClass:[ErrorResponse class]]) {
            XCTAssertNotNil(error.errorMessage,@" Should handled with valid error message");
        } else {
            XCTFail(@"Invalid error response");
        }
        [readyExpectation fulfill];

    }];
    [self waitForExpectationsWithTimeout:5 handler:^(NSError * _Nullable error) {
        NSLog(@"Error of long time consuming task... %@", error);
    }];
    
}

@end
