//
//  YearViewController.m
//  CodingSkillTest

#import "YearViewController.h"
#import "YearVM.h"
#import "MBProgressHUD.h"
#import "CustomTableViewCell.h"
#import "AppDelegate.h"
#import "Constant.h"

@interface YearViewController ()  <UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, weak) IBOutlet UITableView *yearTableView;
@property (nonatomic, weak) IBOutlet UIView *errorView;
@property (nonatomic, weak) IBOutlet UILabel *errorLabelMessage;
@property (nonatomic, strong) YearVM *vmDataSet;

@end

@implementation YearViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"Year";
    
    self.vmDataSet = [[YearVM alloc]init];
    
    
    [self fetchYearData];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Fetch request helper

- (void)fetchYearData {
    if (![self isNetworkAvailable]) {
        return;
    }

    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    __weak YearViewController *weakSelf = self;
    [self.vmDataSet getYearlDataForManufacturer:self.manufaturerReferenceVM.selectedManufacturerUniqueID andMainTYpe:self.modelReferenceVM.selectedModelName onCompletion:^{
        [weakSelf.yearTableView reloadData];
        [MBProgressHUD hideHUDForView:weakSelf.view animated:YES];
    } didFailWithError:^(ErrorResponse *error) {
        [weakSelf showErrorMessage:error.errorMessage];
        [MBProgressHUD hideHUDForView:weakSelf.view animated:YES];
    }];
}

#pragma mark - TableView Delegate

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self.vmDataSet getAllYearDataCount];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *MyIdentifier = @"CustomTableViewCell";
    CustomTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:MyIdentifier];
    NSString *cellName = [self.vmDataSet getYearNameForRow:indexPath.row];
    NSString *cellUniqueId = [self.vmDataSet getYearUniqueIDForRow:indexPath.row];
    [cell updateCellInformationByCellName:cellName andCellUniqueId:cellUniqueId];
    if (indexPath.row %2 == 0) {
        [cell setBackgroundColor:[UIColor colorWithRed:218/255.0 green:229/255.0 blue:228/255.0 alpha:1]];
    } else {
        [cell setBackgroundColor:[UIColor colorWithRed:220/255.0 green:232/255.0 blue:194/255.0 alpha:1]];
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    CustomTableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    NSString *alertMessage = [NSString stringWithFormat:@"%@,%@,%@",self.manufaturerReferenceVM.selectedManufacturerName,self.modelReferenceVM.selectedModelName,cell.cellName.text];
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Selected Data"
                                                                             message:alertMessage
                                                                      preferredStyle:UIAlertControllerStyleAlert];
    //We add buttons to the alert controller by creating UIAlertActions:
    UIAlertAction *actionOk = [UIAlertAction actionWithTitle:@"Ok"
                                                       style:UIAlertActionStyleDefault
                                                     handler:nil]; //You can use a block here to handle a press on this button
    [alertController addAction:actionOk];
    [self presentViewController:alertController animated:YES completion:nil];
    
}

#pragma mark - Error Handler Helper

- (void)showErrorMessage:(NSString*)errorMsg {
    self.errorView.hidden = NO;
    self.errorLabelMessage.text = errorMsg;
}

#pragma mark - IBActrion

- (IBAction)didRetryButtonClicked:(id)sender {
    self.errorView.hidden = YES;
    [self fetchYearData];
}
#pragma mark - Check network availability
- (BOOL)isNetworkAvailable {
    AppDelegate *appDelegate = (AppDelegate*)[UIApplication sharedApplication].delegate;
    
    if(!appDelegate.isNetworkAvailable) {
        [self showErrorMessage:kNetworkErrorMessage];
        return NO;
    }
    return YES;
}
@end
