//
//  NetworkOperation.m
//  CodingSkillTest
//
//  Created by Ajay Kumar Singh on 11/30/16.
//
//

#import "NetworkOperation.h"

@interface NetworkOperation () <NSURLSessionDataDelegate>

@property (nonatomic, copy) NSURL *url;

@end

@implementation NetworkOperation

-(instancetype)initWithURL:(NSURL *)url {
    
    if (self = [super init]) {
        self.url = url;
    }
    return self;
}


#pragma mark - Function to start NSURLSession to fetch data from server.

- (void)startSessionDataTask {
    if (self.url) {
        NSURLSessionConfiguration *defaultConfigObject = [NSURLSessionConfiguration defaultSessionConfiguration];
        NSURLSession *defaultSession = [NSURLSession sessionWithConfiguration: defaultConfigObject delegate: self delegateQueue: [NSOperationQueue mainQueue]];
        
        NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:self.url];
        NSURLSessionDataTask *postDataTask = [defaultSession dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
            
            __weak NetworkOperation *weakSelf = self;
            
            if(error == nil)
            {
                weakSelf.completionBlock(data);
            } else {
                ErrorResponse *errorResponse = [[ErrorResponse alloc]init];
                errorResponse.errorCode = [NSString stringWithFormat:@"%ld",(long)error.code];
                errorResponse.errorMessage = [error localizedDescription];
                weakSelf.errorBlock(errorResponse);
            }
        }];
        
        [postDataTask resume];
        
    }
}

#pragma mark - NSURLSession Authentication challange for trust certificate.
- (void)URLSession:(NSURLSession *)session task:(NSURLSessionTask *)task didReceiveChallenge:(NSURLAuthenticationChallenge *)challenge completionHandler:(void (^)(NSURLSessionAuthChallengeDisposition disposition, NSURLCredential *credential))completionHandler
{
    completionHandler(NSURLSessionAuthChallengeUseCredential, [NSURLCredential credentialForTrust:challenge.protectionSpace.serverTrust]);
}
@end
