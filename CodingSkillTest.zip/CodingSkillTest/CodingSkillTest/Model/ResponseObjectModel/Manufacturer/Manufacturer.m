//
//  Manufacturer.m
//  CodingSkillTest
 
#import "Manufacturer.h"
 
@implementation Manufacturer

@end
