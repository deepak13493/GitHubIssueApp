//
//  CommonModelClass.m
//  CodingSkillTest
 

#import "CommonModelClass.h"

@implementation CommonModelClass

@end
