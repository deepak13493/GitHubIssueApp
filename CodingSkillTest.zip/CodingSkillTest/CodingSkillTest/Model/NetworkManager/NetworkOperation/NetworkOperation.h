//
//  NetworkOperation.h
//  CodingSkillTest
//
//  Created by Ajay Kumar Singh on 11/30/16.
//
//

#import <Foundation/Foundation.h>
#import "ErrorResponse.h"

@interface NetworkOperation : NSObject

@property (copy)void (^completionBlock)(NSData *responseData);
@property (copy)void (^errorBlock)(ErrorResponse *error);

- (instancetype)initWithURL:(NSURL*)url;
- (void)startSessionDataTask;

@end
