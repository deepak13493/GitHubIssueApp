//
//  Constant.h
//  ZendeskExercise
//
//  Created by Ajay Kumar Singh on 11/24/16.
//  Copyright © 2016 Zendesk. All rights reserved.
//

#ifndef Constant_h
#define Constant_h

typedef enum : NSUInteger {
    NEW_TICKET,
    OLD_TICKET,
    SOLVED_TICKET,
} TicketStatus;

#define MainVCSegueName @"MainViewControllerSegue"
#define TicketVCSegueName @"TicketViewControllerSegue"

/*   */
#define Key_Ticket @"tickets"
#define Key_Created_AT @"created_at"
#define Key_Status @"status"
#define Key_Description @"description"
#define Key_Subject @"subject"


#endif /* Constant_h */
