//
//  Issue+CoreDataProperties.m
//  Assignment_UrbanPiper_ObjC
//
//  Created by Bhagyashree on 22/11/16.
//  Copyright © 2016 Bhagyashree. All rights reserved.
//  This file was automatically generated and should not be edited.
//

#import "Issue+CoreDataProperties.h"

@implementation Issue (CoreDataProperties)

+ (NSFetchRequest<Issue *> *)fetchRequest {
	return [[NSFetchRequest alloc] initWithEntityName:@"Issue"];
}

@dynamic comments_url;
@dynamic createdDate;
@dynamic details;
@dynamic state;
@dynamic title;
@dynamic updatedDate;
@dynamic comments;

@end
