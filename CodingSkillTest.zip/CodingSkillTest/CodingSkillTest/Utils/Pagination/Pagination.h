//
//  Pagination.h
//  TestCodingSkill
 
#import <UIKit/UIKit.h>

@protocol PaginationActionDelegate <NSObject>
@optional
- (void)didPreviousButtonClicked:(id)sender;
- (void)didNextButtonClicked:(id)sender;
@end

@interface Pagination : UIView

@property (nonatomic,assign) NSInteger totalPageCount;
@property (nonatomic,assign) NSInteger numberOfRecordsInEachPage;
@property (nonatomic,weak) id <PaginationActionDelegate> paginationDelegate;


@end
