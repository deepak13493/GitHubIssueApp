//
//  IssueTableViewCell.m
//  Assignment_UrbanPiper_ObjC
//
//  Created by Bhagyashree on 22/11/16.
//  Copyright © 2016 Bhagyashree. All rights reserved.
//

#import "IssueTableViewCell.h"
@interface IssueTableViewCell(){
    int characterLimit;
}

@end
@implementation IssueTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

-(void)configureCell:(NSString *)Title andDeatils:(NSString *)details{
    characterLimit = 140;
    if (details) {
        //To Do
        
        _details.text = details subs
        
        
    }
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
