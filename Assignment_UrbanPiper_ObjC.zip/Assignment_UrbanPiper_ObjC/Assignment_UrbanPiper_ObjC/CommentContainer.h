//
//  CommentContainer.h
//  Assignment_UrbanPiper_ObjC
//
//  Created by Bhagyashree on 22/11/16.
//  Copyright © 2016 Bhagyashree. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CommentContainer : NSObject

@property (nonatomic, strong) NSString *userName;
@property (nonatomic, strong) NSString *createdDate;
@property (nonatomic, strong) NSString *updatedDate;
@property (nonatomic, strong) NSString *details;

@end
