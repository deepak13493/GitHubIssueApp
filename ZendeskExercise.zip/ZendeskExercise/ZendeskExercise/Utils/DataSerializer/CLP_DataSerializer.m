//
//  CLP_DataSerializer.m
//  ZendeskExercise
//
//  Created by Ajay Kumar Singh on 11/24/16.
//  Copyright © 2016 Zendesk. All rights reserved.
//

#import "CLP_DataSerializer.h"
#import "CLP_Ticket.h"

@implementation CLP_DataSerializer

+ (NSArray*)serializeAllTicketsForResponseData:(NSData*)responseData {
    NSError *jsonError = nil;
    NSDictionary *jsonObject = [NSJSONSerialization JSONObjectWithData:responseData options:kNilOptions error:&jsonError];
    NSLog(@"All tckets %@",[jsonObject objectForKey:Key_Ticket]);
    return [jsonObject objectForKey:Key_Ticket];
}
@end
