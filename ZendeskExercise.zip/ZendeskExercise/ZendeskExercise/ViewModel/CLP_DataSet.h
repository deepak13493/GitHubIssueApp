//
//  CLPDataSet.h
//  ZendeskExercise
//
//  Created by Ajay Kumar Singh on 11/24/16.
//  Copyright © 2016 Zendesk. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CLP_ErrorResponse.h"

@interface CLP_DataSet : NSObject

//+ (id)sharedDataSet;

- (void)getAllTickets:(void (^)())onCompletion didFailWithError:(void (^)(CLP_ErrorResponse *error))failedWithError;
- (NSUInteger)getAllTicketsCount;

@end
