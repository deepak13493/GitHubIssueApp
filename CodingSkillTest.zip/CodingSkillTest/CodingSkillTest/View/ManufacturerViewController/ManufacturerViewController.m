//
//  ManufacturerViewController.m
//  CodingSkillTest


#import "ManufacturerViewController.h"
#import "Pagination.h"
#import "CustomTableViewCell.h"
#import "MBProgressHUD.h"
#import "ManufacturerVM.h"
#import "ModelViewController.h"
#import "Constant.h"
#import "AppDelegate.h"

@interface ManufacturerViewController () <UITableViewDelegate, UITableViewDataSource, PaginationActionDelegate>

@property (nonatomic, weak) IBOutlet UITableView *manufacturerTableView;
@property (nonatomic, weak) IBOutlet Pagination *paginationControl;
@property (nonatomic, weak) IBOutlet UIView *errorView;
@property (nonatomic, weak) IBOutlet UILabel *errorLabelMessage;
@property (nonatomic, strong) ManufacturerVM *vmDataSet;
@property (nonatomic, assign) NSInteger pageValue;

@end

@implementation ManufacturerViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.paginationControl.paginationDelegate = self;
    self.paginationControl.hidden = YES;
    
    self.vmDataSet = [[ManufacturerVM alloc]init];
    self.pageValue = 0;
    [self fetchManufacturerData]; // Call to fetch data from server

}

#pragma mark - Fetch Request Helper

- (void)fetchManufacturerData {
    if (![self isNetworkAvailable]) {
        return;
    }
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    __weak ManufacturerViewController *weakSelf = self;
    [self.vmDataSet getManufacturerDataForPage:self.pageValue pageSize:kDefaultPageSize onCompletion:^{
        if (weakSelf.paginationControl.hidden) {
            weakSelf.paginationControl.numberOfRecordsInEachPage = kDefaultPageSize;
            weakSelf.paginationControl.totalPageCount = [weakSelf.vmDataSet getTotalPageCount];
            weakSelf.paginationControl.hidden = NO;
        }
        [weakSelf.manufacturerTableView reloadData];
        [MBProgressHUD hideHUDForView:weakSelf.view animated:YES];
    } didFailWithError:^(ErrorResponse *error) {
        [weakSelf showErrorMessage:error.errorMessage];
        [MBProgressHUD hideHUDForView:weakSelf.view animated:YES];
    }];
}

#pragma mark - TableView Delegate

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self.vmDataSet getAllManufacturersCount];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *MyIdentifier = @"CustomTableViewCell";
    CustomTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:MyIdentifier];
    NSString *cellName = [self.vmDataSet getManufacturerNameForRow:indexPath.row];
    NSString * cellUniqueId = [self.vmDataSet getManufacturerUniqueIDForRow:indexPath.row];
    [cell updateCellInformationByCellName:cellName andCellUniqueId:cellUniqueId];
    if (indexPath.row %2 == 0) {
        [cell setBackgroundColor:[UIColor colorWithRed:218/255.0 green:229/255.0 blue:228/255.0 alpha:1]];
    } else {
        [cell setBackgroundColor:[UIColor colorWithRed:220/255.0 green:232/255.0 blue:194/255.0 alpha:1]];
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (![self isNetworkAvailable]) {
        return;
    }
    
    CustomTableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];    
    self.vmDataSet.selectedManufacturerName = cell.cellName.text;
    self.vmDataSet.selectedManufacturerUniqueID = cell.cellUniqueID;
    
    [self performSegueWithIdentifier:@"ModelViewControllerSegue" sender:nil];
}

#pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
     if ([segue.identifier isEqualToString:@"ModelViewControllerSegue"]) {
         ModelViewController *vc = [segue destinationViewController];
         vc.manufaturerReferenceVM = self.vmDataSet;
     }
 }
 
#pragma mark - Pagination Delegate

- (void)didPreviousButtonClicked:(id)sender {
    self.pageValue--;
    [self fetchManufacturerData];
}

- (void)didNextButtonClicked:(id)sender {
    self.pageValue++;
    [self fetchManufacturerData];
}

#pragma mark - Error Handler Helper

- (void)showErrorMessage:(NSString*)errorMsg {
    self.errorView.hidden = NO;
    self.errorLabelMessage.text = errorMsg;
}

#pragma mark - IBActrion

- (IBAction)didRetryButtonClicked:(id)sender {
    self.errorView.hidden = YES;
    [self fetchManufacturerData];
}

#pragma mark - Check network availability

- (BOOL)isNetworkAvailable {
    AppDelegate *appDelegate = (AppDelegate*)[UIApplication sharedApplication].delegate;
    
    if(!appDelegate.isNetworkAvailable) {
        [self showErrorMessage:kNetworkErrorMessage];
        return NO;
    }
    return YES;
}
@end
