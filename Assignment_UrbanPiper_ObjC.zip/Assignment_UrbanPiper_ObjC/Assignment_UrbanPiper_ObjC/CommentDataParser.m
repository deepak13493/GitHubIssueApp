//
//  CommentDataParser.m
//  Assignment_UrbanPiper_ObjC
//
//  Created by Bhagyashree on 22/11/16.
//  Copyright © 2016 Bhagyashree. All rights reserved.
//

#import "CommentDataParser.h"
@interface CommentDataParser ()
@property (nonatomic, strong) CommentContainer *comment;
@end

@implementation CommentDataParser

-(CommentContainer*) parse:(NSData *)forData{
    
    NSError *error = nil;
    NSData *data = nil;
    
    @try {
        data = [NSJSONSerialization dataWithJSONObject:forData options:0 error:&error];
        
    }
    @catch (NSException *exception) {
        NSLog(@"%@ exception encoding api data: %@", self, exception);
    }
    if (error) {
        NSLog(@"%@ error encoding api data: %@", self, error);
    }
    return data;
}
//- (CommentContainer*) fillModelClass: (id)forObject{
  //  NSString *usernmae;
    //NSDictionary *userDetails;
    //for (userDetails in forObject[@"user"]){
        
    //}
//}


@end
