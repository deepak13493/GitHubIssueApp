//
//  BaseViewController.m
//  Assignment_UrbanPiper_ObjC
//
//  Created by Bhagyashree on 22/11/16.
//  Copyright © 2016 Bhagyashree. All rights reserved.
//

#import "BaseViewController.h"

@interface BaseViewController ()

@end

@implementation BaseViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
}

-(void) showActivityView{
    _activityView.center = CGPointMake(self.view.frame.size.width / 2.0, self.view.frame.size.height / 2.0);
    self.view.userInteractionEnabled = NO;
    _activityView.backgroundColor = [UIColor lightGrayColor];
    
    dispatch_async(dispatch_get_main_queue(), ^void{
        [self.activityView startAnimating];
        [self.view addSubview:self.activityView];
        
    });
    
}


-(void) hideActivityView{
    dispatch_async(dispatch_get_main_queue(), ^void{
        [self.view isUserInteractionEnabled];
        [self.activityView stopAnimating];
        [self.activityView removeFromSuperview];
        
    });
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
