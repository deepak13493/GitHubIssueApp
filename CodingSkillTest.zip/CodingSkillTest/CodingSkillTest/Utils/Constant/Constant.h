//
//  Constant.h
//  CodingSkillTest
//
//  Created by Ajay Kumar Singh on 11/30/16.
//
//

#ifndef Constant_h
#define Constant_h

/***** Network Error Response *****/
#define kNetworkErrorMessage @"Network not reachable"

/********* Reachability ********/
#define kNetworkReachabilityChangedNotification @"kNetworkReachabilityChangedNotification"
 

/*  ------ Manufacturer/Model Response Keys ----------- */

#define kPage @"page"
#define kPageSize @"pageSize"
#define kTotalPageCount @"totalPageCount"
#define kWKDA    @"wkda"
#define kDefaultPageSize 10

  
 //Reference :- http://api.wkda-test.com/v1/car-types/manufacturer?page=0&pageSize=10&wa_key=coding-puzzle-client-449cc9d
#define kWAKey @"coding-puzzle-client-449cc9d"
#define kBaseURL @"http://api.wkda-test.com"
#define kManufacturerWebServiceURL @"/v1/car-types/manufacturer?"

// Reference :- 	http://api.wkda-test.com/v1/car-types/main-types?manufacturer=107&page=0&pageSize=10&wa_key=coding-puzzle-client-449cc9d
#define kModelWebServiceURL @"/v1/car-types/main-types?"

//Reference :- http://api.wkda-test.com/v1/car-types/built-dates?manufacturer=107&main-type=Arnage&wa_key=coding-puzzle-client-449cc9d

#define kYearWebServiceURL @"/v1/car-types/built-dates?"


#endif /* Constant_h */
