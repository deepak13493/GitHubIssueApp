//
//  CLPTicketTableTableViewController.h
//  ZendeskExercise
//
//  Created by Ajay Kumar Singh on 11/24/16.
//  Copyright © 2016 Zendesk. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CLP_TicketTableTableViewController : UIViewController

@end
