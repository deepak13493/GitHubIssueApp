//
//  Issue+CoreDataProperties.h
//  Assignment_UrbanPiper_ObjC
//
//  Created by Bhagyashree on 22/11/16.
//  Copyright © 2016 Bhagyashree. All rights reserved.
//  This file was automatically generated and should not be edited.
//

#import "Issue+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface Issue (CoreDataProperties)

+ (NSFetchRequest<Issue *> *)fetchRequest;

@property (nullable, nonatomic, copy) NSString *comments_url;
@property (nullable, nonatomic, copy) NSDate *createdDate;
@property (nullable, nonatomic, copy) NSString *details;
@property (nullable, nonatomic, copy) NSString *state;
@property (nullable, nonatomic, copy) NSString *title;
@property (nullable, nonatomic, copy) NSDate *updatedDate;
@property (nullable, nonatomic, retain) Comment *comments;

@end

NS_ASSUME_NONNULL_END
